"use client";

import { useState } from "react";

type Role = "owner" | "admin";

export default function SecretGate({ onClose }: { onClose: () => void }) {
  const [tab, setTab] = useState<Role>("owner");
  const [ownerPwd, setOwnerPwd] = useState("");
  const [adminPwd, setAdminPwd] = useState("");
  const [showOwner, setShowOwner] = useState(false);
  const [showAdmin, setShowAdmin] = useState(false);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");
  const [shakeKey, setShakeKey] = useState(0);

  async function loginOwner() {
    setErr("");
    if (!ownerPwd) {
      setErr("Masukkan password Owner.");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("/api/auth/owner/login", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ password: ownerPwd }),
      });
      const j = await res.json();
      if (!res.ok) {
        setErr(j.error || "Login owner gagal.");
        setShakeKey((k) => k + 1);
        return;
      }
      try {
        sessionStorage.setItem("cg_owner_token", j.token);
      } catch {}
      window.location.href = "/owner";
    } catch {
      setErr("Jaringan bermasalah. Coba lagi.");
    } finally {
      setLoading(false);
    }
  }

  async function loginAdmin() {
    setErr("");
    if (!adminPwd) {
      setErr("Masukkan password kamu.");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("/api/auth/admin/login", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ password: adminPwd }),
      });
      const j = await res.json();
      if (!res.ok) {
        setErr(j.error || "Login admin gagal.");
        setShakeKey((k) => k + 1);
        return;
      }
      try {
        sessionStorage.setItem("cg_admin_token", j.token);
        sessionStorage.setItem("cg_admin_slug", j.tenant?.slug || "");
      } catch {}
      window.location.href = "/admin";
    } catch {
      setErr("Jaringan bermasalah. Coba lagi.");
    } finally {
      setLoading(false);
    }
  }

  function switchTab(t: Role) {
    setTab(t);
    setErr("");
    // Bersihkan field saat pindah tab agar tidak ada sisa password/token terlihat
    if (t === "owner") setAdminPwd("");
    else setOwnerPwd("");
  }

  return (
    <div className="secret-overlay" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div key={shakeKey} className={`secret-card ${err ? "shake" : ""}`}>
        <div style={{ padding: "20px 20px 14px", display: "flex", alignItems: "center", gap: 12 }}>
          <div className="brand-icon" style={{ width: 38, height: 38 }}>
            <i className="fa-solid fa-gem" />
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 800, fontSize: 15, letterSpacing: 0.3 }}>AKSES RAHASIA</div>
            <div style={{ fontSize: 12, color: "#8a99b9" }}>Pilih jalur login.</div>
          </div>
          <button className="btn-ghost" onClick={onClose} style={{ width: 38, padding: "8px 0" }}>✕</button>
        </div>

        <div className="secret-tabs">
          <button className={`secret-tab ${tab === "owner" ? "active-owner" : ""}`} onClick={() => switchTab("owner")}>
            <i className="fa-solid fa-crown" style={{ marginRight: 8 }} />OWNER
          </button>
          <button className={`secret-tab ${tab === "admin" ? "active-admin" : ""}`} onClick={() => switchTab("admin")}>
            <i className="fa-solid fa-user-shield" style={{ marginRight: 8 }} />ADMIN / PENYEWA
          </button>
        </div>

        <div style={{ padding: 20 }}>
          {tab === "owner" ? (
            <div>
              <div className="panel" style={{ marginBottom: 14, borderColor: "rgba(245,158,11,0.3)" }}>
                <div className="panel-head">
                  <i className="fa-solid fa-crown" style={{ color: "#fbbf24" }} />
                  <div>
                    <div className="panel-title">Login Owner</div>
                    <div className="panel-sub">Khusus pemilik.</div>
                  </div>
                </div>
                <div className="panel-body">
                  <label style={{ fontSize: 12, color: "#8a99b9", fontWeight: 700 }}>PASSWORD OWNER</label>
                  <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
                    <input
                      className="field"
                      type={showOwner ? "text" : "password"}
                      placeholder="••••••••"
                      value={ownerPwd}
                      onChange={(e) => setOwnerPwd(e.target.value)}
                      onKeyDown={(e) => { if (e.key === "Enter") loginOwner(); }}
                      autoComplete="off"
                      autoCorrect="off"
                      autoCapitalize="off"
                      spellCheck={false}
                      data-lpignore="true"
                      data-form-type="other"
                    />
                    <button className="btn-ghost" onClick={() => setShowOwner((s) => !s)} style={{ whiteSpace: "nowrap" }}>
                      {showOwner ? "Sembunyi" : "Lihat"}
                    </button>
                  </div>
                  <button className="btn-primary" onClick={loginOwner} disabled={loading} style={{ marginTop: 12, background: "linear-gradient(90deg,#f59e0b,#ef4444)" }}>
                    {loading ? "Memeriksa..." : "Masuk sebagai OWNER"}
                  </button>
                </div>
              </div>
              <div style={{ fontSize: 11.5, color: "#6b7a99", lineHeight: 1.6 }}>
                Password Owner bersifat rahasia &amp; tidak pernah ditampilkan di layar mana pun.
              </div>
            </div>
          ) : (
            <div>
              <div className="panel" style={{ marginBottom: 14, borderColor: "rgba(168,85,247,0.35)" }}>
                <div className="panel-head">
                  <i className="fa-solid fa-user-shield" style={{ color: "#c084fc" }} />
                  <div>
                    <div className="panel-title">Login Admin / Penyewa</div>
                    <div className="panel-sub">1 password = 1 admin sendiri.</div>
                  </div>
                </div>
                <div className="panel-body">
                  <label style={{ fontSize: 12, color: "#8a99b9", fontWeight: 700 }}>PASSWORD</label>
                  <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
                    <input
                      className="field"
                      type={showAdmin ? "text" : "password"}
                      placeholder="••••••••"
                      value={adminPwd}
                      onChange={(e) => setAdminPwd(e.target.value)}
                      onKeyDown={(e) => { if (e.key === "Enter") loginAdmin(); }}
                      autoComplete="off"
                      autoCorrect="off"
                      autoCapitalize="off"
                      spellCheck={false}
                      data-lpignore="true"
                      data-form-type="other"
                    />
                    <button className="btn-ghost" onClick={() => setShowAdmin((s) => !s)} style={{ whiteSpace: "nowrap" }}>
                      {showAdmin ? "Sembunyi" : "Lihat"}
                    </button>
                  </div>
                  <button className="btn-primary" onClick={loginAdmin} disabled={loading} style={{ marginTop: 12 }}>
                    {loading ? "Memeriksa..." : "Masuk sebagai ADMIN"}
                  </button>
                </div>
              </div>
              <div style={{ fontSize: 11.5, color: "#6b7a99", lineHeight: 1.6 }}>
                Masukkan password yang diberikan Owner. Jangan dibagikan ke siapa pun.
              </div>
            </div>
          )}

          {err && (
            <div style={{ marginTop: 14, background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.3)", color: "#fca5a5", fontSize: 12.5, padding: "10px 12px", borderRadius: 12 }}>
              <i className="fa-solid fa-triangle-exclamation" style={{ marginRight: 8 }} />{err}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
