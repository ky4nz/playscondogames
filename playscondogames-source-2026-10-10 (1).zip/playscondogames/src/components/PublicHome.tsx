"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import SecretGate from "./SecretGate";
import AntiInspect from "./AntiInspect";
import BrowserModal, { type RoomData } from "./BrowserModal";

type Server = {
  slot: number;
  title: string;
  online: number;
  maxOnline: number;
  imageUrl: string;
  gameBy: string;
  gameDesc: string;
  maturity: string;
  isActive: boolean;
  linksComplete?: boolean;
  linksCount?: number;
  roomPath: string;
};

// Avatar PREMIUM berobux — cowok + cewek (headshot asli Roblox, bukan AI).
// Cowok: Linkmon99, Builderman, Shedletsky, Stickmasterluke, Berezaa, KreekCraft, Merely, Telamon, SonOfSevenless, EarlGrey
// Cewek: callmehbob (Royale High), MeganPlays, LeahAshe, ItsFunneh, Aphmau, ROYALEHIGH
const PREMIUM_MALE = [
  "https://tr.rbxcdn.com/30DAY-AvatarHeadshot-89A5211C79181E57B2B08FB4A94B89BC-Png/150/150/AvatarHeadshot/Png/noFilter",
  "https://tr.rbxcdn.com/30DAY-AvatarHeadshot-635A2AA0A87D473B6136800B5B86F761-Png/150/150/AvatarHeadshot/Png/noFilter",
  "https://tr.rbxcdn.com/30DAY-AvatarHeadshot-3B3B81F4602EE5424673376A726F427E-Png/150/150/AvatarHeadshot/Png/noFilter",
  "https://tr.rbxcdn.com/30DAY-AvatarHeadshot-1A9690EEAE8B9EA3D01BBC9ABF8CA7E1-Png/150/150/AvatarHeadshot/Png/noFilter",
  "https://tr.rbxcdn.com/30DAY-AvatarHeadshot-A2B73419EE08445EB57DDE508113E48E-Png/150/150/AvatarHeadshot/Png/noFilter",
  "https://tr.rbxcdn.com/30DAY-AvatarHeadshot-C55E4D4D436D539EA5719757B05DC54F-Png/150/150/AvatarHeadshot/Png/noFilter",
  "https://tr.rbxcdn.com/30DAY-AvatarHeadshot-8657A13C05B234D24CA3FC29F5AA0BCF-Png/150/150/AvatarHeadshot/Png/noFilter",
  "https://tr.rbxcdn.com/30DAY-AvatarHeadshot-5A236C18E2A030F544316F10E6E0901F-Png/150/150/AvatarHeadshot/Png/noFilter",
  "https://tr.rbxcdn.com/30DAY-AvatarHeadshot-A8A8F3283325C7DC15ECDE3A8B8547AF-Png/150/150/AvatarHeadshot/Png/noFilter",
  "https://tr.rbxcdn.com/30DAY-AvatarHeadshot-C5B1AF429380EBA90BB625F51ACE2446-Png/150/150/AvatarHeadshot/Png/noFilter",
];

const PREMIUM_FEMALE = [
  "https://tr.rbxcdn.com/30DAY-AvatarHeadshot-084FA21EAC174D1A538D31F04854BBC0-Png/150/150/AvatarHeadshot/Png/noFilter",
  "https://tr.rbxcdn.com/30DAY-AvatarHeadshot-2E439E8AC3556D07A50E9E7C79CFC43C-Png/150/150/AvatarHeadshot/Png/noFilter",
  "https://tr.rbxcdn.com/30DAY-AvatarHeadshot-4CA63262CBDDABD64BDFE0C6F2F8EB7D-Png/150/150/AvatarHeadshot/Png/noFilter",
  "https://tr.rbxcdn.com/30DAY-AvatarHeadshot-5F469438C6F60FCA77C28D2151550AB1-Png/150/150/AvatarHeadshot/Png/noFilter",
  "https://tr.rbxcdn.com/30DAY-AvatarHeadshot-E355ACC3EC9273C69F8454260C14BD7E-Png/150/150/AvatarHeadshot/Png/noFilter",
  "https://tr.rbxcdn.com/30DAY-AvatarHeadshot-2F7FF3626B892C9DBBE9593A4F78E6D6-Png/150/150/AvatarHeadshot/Png/noFilter",
];

const PREMIUM_ALL = [...PREMIUM_MALE, ...PREMIUM_FEMALE];

function pickPremiumAvatars(slot: number, count: number, seed: number): string[] {
  // Campur cowok + cewek, beda tiap server & tiap putaran (seperti player keluar-masuk)
  const out: string[] = [];
  const total = PREMIUM_ALL.length;
  let idx = (seed * 5 + slot * 7) % total;
  while (out.length < count) {
    const url = PREMIUM_ALL[idx % total];
    if (!out.includes(url)) out.push(url);
    idx += 3;
    if (idx > 1000) break;
  }
  // Pastikan minimal 1 cewek & 1 cowok jika count >= 2
  if (count >= 2) {
    const hasM = out.some((u) => PREMIUM_MALE.includes(u));
    const hasF = out.some((u) => PREMIUM_FEMALE.includes(u));
    if (!hasM) out[0] = PREMIUM_MALE[(seed + slot) % PREMIUM_MALE.length];
    if (!hasF) out[1 % out.length] = PREMIUM_FEMALE[(seed + slot * 2) % PREMIUM_FEMALE.length];
  }
  return out;
}

// 2 FOTO ASLI milik user — jangan dihapus. Dipakai sebagai fallback agar banner tidak pernah hilang.
const ORIGINAL_BANNERS: Record<number, string> = {
  1: "https://i.ibb.co.com/cKZZwDDK/Whats-App-Image-2026-10-07-at-2-09-28-AM.jpg",
  2: "https://raw.githubusercontent.com/tokun787-boop/Condo-Games-/main/image/server2.jpg",
  3: "https://i.ibb.co.com/cKZZwDDK/Whats-App-Image-2026-10-07-at-2-09-28-AM.jpg",
};

type Branding = {
  siteName1: string;
  siteName2: string;
  heroTitle: string;
  heroSubtitle: string;
  heroVideo: string;
  heroAvatar: string;
  heroAvatarName: string;
  sectionTitle: string;
};

const DEFAULT_BRANDING: Branding = {
  siteName1: "CONDO",
  siteName2: "GAMES",
  heroTitle: "Condo Games Private",
  heroSubtitle: "Choose your favorite Roblox private server and join now",
  heroVideo: "https://raw.githubusercontent.com/tokun787-boop/Condo-Games-/main/image/vidio.mp4",
  heroAvatar: "https://tr.rbxcdn.com/30DAY-AvatarHeadshot-A4F764CB5B7A62140A826DCBA9EE5F7E-Png/150/150/AvatarHeadshot/Webp/noFilter",
  heroAvatarName: "Condo_Games",
  sectionTitle: "Private Servers",
};

export default function PublicHome({ initialTenant = "" }: { initialTenant?: string }) {
  const [booted, setBooted] = useState(false);
  const [progress, setProgress] = useState(0);
  const [tenantSlug, setTenantSlug] = useState(initialTenant || "owner");
  const [servers, setServers] = useState<Server[]>([]);
  const [branding, setBranding] = useState<Branding>(DEFAULT_BRANDING);
  const [loadingServers, setLoadingServers] = useState(true);
  // Live dummy: online + avatar berganti seperti player keluar-masuk
  const [liveOnline, setLiveOnline] = useState<Record<number, number>>({});
  const [liveAvatars, setLiveAvatars] = useState<Record<number, string[]>>({});
  const [liveTick, setLiveTick] = useState(0);
  const liveOnlineRef = useRef<Record<number, number>>({});
  useEffect(() => {
    liveOnlineRef.current = liveOnline;
  }, [liveOnline]);

  const [connecting, setConnecting] = useState(false);
  const [connectText, setConnectText] = useState("Please wait");
  const [connectTitle, setConnectTitle] = useState("Connecting...");

  const [modalOpen, setModalOpen] = useState(false);
  const [room, setRoom] = useState<RoomData | null>(null);

  const [secretOpen, setSecretOpen] = useState(false);
  const taps = useRef<number[]>([]);
  const autoOpened = useRef(false);
  // Silent counter — TANPA hint/petunjuk apa pun di layar

  useEffect(() => {
    let width = 0;
    const iv = window.setInterval(() => {
      if (width >= 100) {
        window.clearInterval(iv);
        window.setTimeout(() => setBooted(true), 500);
      } else {
        const step = Math.floor(Math.random() * 12) + 6;
        width = Math.min(width + step, 100);
        setProgress(width);
      }
    }, 140);
    return () => window.clearInterval(iv);
  }, []);

  useEffect(() => {
    try {
      const q = new URLSearchParams(window.location.search).get("r");
      if (q && q.trim()) setTenantSlug(q.trim());
      else if (initialTenant) setTenantSlug(initialTenant);
    } catch {}
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const loadServers = useCallback(async (slug: string, silent = false) => {
    if (!silent) setLoadingServers(true);
    try {
      const res = await fetch(`/api/public/servers?r=${encodeURIComponent(slug)}`, { cache: "no-store" });
      const j = await res.json();
      if (res.ok) {
        const list: Server[] = j.servers || [];
        setServers(list);
        if (j.branding) setBranding({ ...DEFAULT_BRANDING, ...j.branding });
        // Init live online + avatar premium (cowok+cewek) per server
        setLiveOnline((prev) => {
          const next: Record<number, number> = { ...prev };
          for (const s of list) {
            if (next[s.slot] === undefined) next[s.slot] = s.online ?? 0;
          }
          return next;
        });
        setLiveAvatars((prev) => {
          const next: Record<number, string[]> = { ...prev };
          for (const s of list) {
            if (!next[s.slot]) {
              const count = s.slot === 2 ? 2 : 3;
              next[s.slot] = pickPremiumAvatars(s.slot, count, s.slot * 11);
            }
          }
          return next;
        });
      }
    } catch {}
    finally {
      setLoadingServers(false);
    }
  }, []);

  useEffect(() => {
    if (booted && tenantSlug) loadServers(tenantSlug);
  }, [booted, tenantSlug, loadServers]);

  // Auto-refresh: jika Owner/Member ganti map/web/link, publik ikut ganti otomatis tanpa reload manual.
  useEffect(() => {
    if (!booted || !tenantSlug) return;
    const iv = window.setInterval(() => {
      loadServers(tenantSlug, true);
    }, 15000);
    const onVis = () => {
      if (document.visibilityState === "visible") loadServers(tenantSlug, true);
    };
    document.addEventListener("visibilitychange", onVis);
    return () => {
      window.clearInterval(iv);
      document.removeEventListener("visibilitychange", onVis);
    };
  }, [booted, tenantSlug, loadServers]);

  // Simulasi player keluar-masuk: online naik-turun + avatar berganti tiap 3.5 detik.
  // Jika 20/20 → FULL otomatis, harus pilih server lain.
  useEffect(() => {
    if (!booted || servers.length === 0) return;
    const iv = window.setInterval(() => {
      setLiveTick((t) => t + 1);
      setLiveOnline((prev) => {
        const next: Record<number, number> = { ...prev };
        for (const s of servers) {
          if (!s.isActive) continue;
          const max = s.maxOnline || 20;
          let cur = next[s.slot];
          if (cur === undefined) cur = s.online ?? 0;
          // Random walk: -2..+2, dengan peluang naik lebih besar saat sepi & turun saat penuh
          let d = Math.floor(Math.random() * 5) - 2;
          if (cur >= max) d = -Math.floor(Math.random() * 2) - 1; // penuh → ada yang keluar
          else if (cur >= max - 2) d = Math.random() < 0.5 ? 1 : -1; // dekat penuh → bisa full
          else if (cur <= 2) d = Math.floor(Math.random() * 3); // sepi → cenderung naik
          let n = cur + d;
          if (n < 0) n = 0;
          if (n > max) n = max;
          next[s.slot] = n;
        }
        return next;
      });
      setLiveAvatars((prev) => {
        const next: Record<number, string[]> = { ...prev };
        const seed = Math.floor(Date.now() / 3500);
        for (const s of servers) {
          if (!s.isActive) continue;
          const cur = liveOnlineRef.current[s.slot] ?? s.online ?? 0;
          // Jumlah avatar ikut ramai: 2-4 avatar
          const count = cur >= 12 ? 4 : cur >= 5 ? 3 : 2;
          next[s.slot] = pickPremiumAvatars(s.slot, count, seed + s.slot);
        }
        return next;
      });
    }, 3500);
    return () => window.clearInterval(iv);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [booted, servers.length]);

  // Diamond kiri-atas: diam-diam dihitung, TANPA petunjuk. 3x ketuk → halaman login fullscreen.
  function onDiamondTap() {
    const now = Date.now();
    taps.current = [...taps.current.filter((t) => now - t < 2500), now];
    if (taps.current.length >= 3) {
      taps.current = [];
      setModalOpen(false);
      setSecretOpen(true);
    }
  }

  function liveCountFor(s: Server): number {
    const v = liveOnline[s.slot];
    if (typeof v === "number") return v;
    return s.online ?? 0;
  }

  function isFullFor(s: Server): boolean {
    return liveCountFor(s) >= (s.maxOnline || 20);
  }

  async function handleJoin(slot: number) {
    if (connecting) return;
    const target = servers.find((x) => x.slot === slot);
    if (target && isFullFor(target)) {
      setConnectTitle("Server Full");
      setConnectText(`Server 0${slot} Full (${liveCountFor(target)}/${target.maxOnline || 20}). Pilih server lain.`);
      setConnecting(true);
      window.setTimeout(() => {
        setConnecting(false);
        setConnectTitle("Connecting...");
        setConnectText("Please wait");
      }, 2500);
      return;
    }
    setConnectTitle("Connecting...");
    setConnectText(`Connecting to Server ${slot}...`);
    setConnecting(true);
    try {
      const res = await fetch("/api/public/join", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ tenantSlug, slot }),
      });
      const j = await res.json();
      if (!res.ok || !j.room) {
        setConnectTitle("⚠️ Configuration Missing");
        setConnectText(j.error || "Please login to admin panel to set the server URL.");
        window.setTimeout(() => {
          setConnecting(false);
          setConnectTitle("Connecting...");
        }, 3000);
        return;
      }
      window.setTimeout(() => {
        setConnecting(false);
        setRoom(j.room as RoomData);
        setModalOpen(true);
        // Kamu ikut masuk → online +1 (bisa bikin full)
        setLiveOnline((prev) => {
          const max = target?.maxOnline || 20;
          const cur = prev[slot] ?? target?.online ?? 0;
          return { ...prev, [slot]: Math.min(cur + 1, max) };
        });
        setLiveAvatars((prev) => {
          const seed = Math.floor(Date.now() / 1000);
          const count = 4;
          return { ...prev, [slot]: pickPremiumAvatars(slot, count, seed) };
        });
      }, 1200);
    } catch {
      setConnectTitle("Connecting...");
      setConnectText("Please wait");
      window.setTimeout(() => setConnecting(false), 2000);
    }
  }

  const activeServers = servers.filter((s) => s.isActive);
  const onlineTotal = activeServers.reduce((a, s) => a + liveCountFor(s), 0);
  void liveTick;

  // Deep link per server: /r/slug?server=1 atau /?r=slug&server=1 → otomatis buka modal server itu
  useEffect(() => {
    if (!booted || loadingServers || autoOpened.current) return;
    try {
      const sp = new URLSearchParams(window.location.search);
      const want = Number(sp.get("server") || sp.get("auto") || 0);
      if ([1, 2, 3].includes(want) && activeServers.some((s) => s.slot === want)) {
        autoOpened.current = true;
        window.setTimeout(() => handleJoin(want), 600);
      }
    } catch {}
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [booted, loadingServers, activeServers.length]);

  // Saat mode rahasia dibuka: SEMBUNYIKAN TOTAL web/banner/join — hanya halaman login fullscreen.
  if (secretOpen) {
    return (
      <AntiInspect label="AKSES RAHASIA TERPROTEKSI">
        <SecretGate onClose={() => setSecretOpen(false)} />
      </AntiInspect>
    );
  }

  const siteFull = `${branding.siteName1} ${branding.siteName2}`.trim() || "CONDO GAMES";

  return (
    <AntiInspect label={`${siteFull} TERPROTEKSI`}>
      {!booted && (
        <div id="loading-screen">
          <div style={{ position: "relative", width: 90, height: 90 }}>
            <div className="loader-ring" />
            <div className="loader-gem"><i className="fa-solid fa-gem" /></div>
          </div>
          <div className="loading-title">WELCOME TO <span>{siteFull}</span></div>
          <div className="loading-bar-track">
            <div className="loading-bar-fill" id="loading-bar" style={{ width: `${progress}%` }} />
          </div>
          <div className="loading-text" id="loading-text">Loading... {progress > 0 ? `${progress}%` : ""}</div>
        </div>
      )}

      <div id="app-content" style={{ display: booted ? "block" : "none" }}>
        <header className="navbar">
          <div className="nav-brand">
            <div className="brand-hit" onClick={onDiamondTap} title={siteFull}>
              <div className="brand-icon"><i className="fa-solid fa-gem" /></div>
              <span>{branding.siteName1} <span>{branding.siteName2}</span></span>
            </div>
          </div>
          {tenantSlug !== "owner" ? (
            <span className="admin-link" style={{ pointerEvents: "none" }}>{tenantSlug}</span>
          ) : (
            <span />
          )}
        </header>

        <div className="hero-banner">
          <div className="hero-video-wrapper">
            <span className="live-badge"><i className="fa-solid fa-circle" style={{ fontSize: 8, marginRight: 4, verticalAlign: "middle" }} /> LIVE</span>
            <video key={branding.heroVideo} autoPlay loop muted playsInline>
              <source src={branding.heroVideo} type="video/mp4" />
            </video>
            <div className="hero-avatar-overlay">
              <img className="hero-avatar-img" src={branding.heroAvatar} alt="avatar" />
              <span className="hero-avatar-name">{branding.heroAvatarName}</span>
            </div>
          </div>
          <div className="hero-content">
            <h1>{branding.heroTitle}</h1>
            <p>{branding.heroSubtitle}</p>
          </div>
        </div>

        <div className="section-header">
          <div className="section-title">
            <i className="fa-solid fa-gem" /> {branding.sectionTitle}
          </div>
          <div className="section-stats">
            {activeServers.length} Servers • <span id="onlineCount">{onlineTotal}</span> Online
          </div>
        </div>

        <div className="server-list">
          {loadingServers && (
            <div className="server-card">
              <div className="server-info" style={{ textAlign: "center", color: "#9aa9c7", fontSize: 13 }}>Loading...</div>
            </div>
          )}
          {!loadingServers && activeServers.length === 0 && (
            <div className="server-card">
              <div className="server-info" style={{ textAlign: "center" }}>
                <div className="server-name">No servers available</div>
                <div style={{ fontSize: 12, color: "#8a99b9" }}>Please login to admin panel to set the server URL.</div>
              </div>
            </div>
          )}
          {activeServers.map((s) => {
            const count = liveCountFor(s);
            const max = s.maxOnline || 20;
            const full = count >= max;
            const avatars: string[] = liveAvatars[s.slot] || pickPremiumAvatars(s.slot, s.slot === 2 ? 2 : 3, s.slot * 11);
            return (
              <div className="server-card" key={s.slot}>
                <div className="server-thumb">
                  {full ? (
                    <span className="available-tag" style={{ background: "rgba(239,68,68,0.2)", borderColor: "rgba(239,68,68,0.35)", color: "#f87171" }}>
                      <i className="fa-solid fa-circle-xmark" style={{ fontSize: 9, marginRight: 4 }} /> FULL
                    </span>
                  ) : (
                    <span className="available-tag"><i className="fa-solid fa-check-circle" style={{ fontSize: 9, marginRight: 4 }} /> AVAILABLE</span>
                  )}
                  <img
                    src={s.imageUrl || ORIGINAL_BANNERS[s.slot] || ORIGINAL_BANNERS[1]}
                    alt={`Server ${s.slot} banner`}
                    draggable={false}
                    onError={(e) => { const t = e.currentTarget; const fb = ORIGINAL_BANNERS[s.slot] || ORIGINAL_BANNERS[1]; if (t.src !== fb) t.src = fb; }}
                  />
                </div>
                <div className="server-info">
                  <div className="server-name">{s.title}</div>
                  <div className="player-strip">
                    {avatars.map((a: string, k: number) => (
                      <img key={`${s.slot}-${k}-${a.slice(-12)}`} className="player-avatar-sm" src={a} alt="player" draggable={false} />
                    ))}
                    <span className="player-count-label">{count} / {max} Online{full ? " • FULL" : ""}</span>
                  </div>
                  <button
                    className="join-btn"
                    data-server={s.slot}
                    disabled={full}
                    onClick={(e) => { e.stopPropagation(); handleJoin(s.slot); }}
                    style={full ? { background: "#3f3f46", boxShadow: "none", cursor: "not-allowed" } : undefined}
                  >
                    {full ? "SERVER FULL — PILIH SERVER LAIN" : "JOIN SERVER"}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className={`loading-modal ${connecting ? "active" : ""}`} id="loadingModal">
        <div className="loading-content">
          <div className="loading-spinner" />
          <h3 id="loadingTitle">{connectTitle}</h3>
          <p id="loadingText">{connectText}</p>
        </div>
      </div>

      <BrowserModal key={room ? `${tenantSlug}-${room.slot}` : "closed"} open={modalOpen} room={room} onClose={() => { setModalOpen(false); setRoom(null); }} />
    </AntiInspect>
  );
}
