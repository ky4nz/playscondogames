"use client";

import { useEffect, useState } from "react";

type Branding = {
  siteName1: string;
  siteName2: string;
  heroTitle: string;
  heroSubtitle: string;
  heroVideo: string;
  heroAvatar: string;
  heroAvatarName: string;
  sectionTitle: string;
};

export default function WebsiteBrandingCard({
  kind,
  getToken,
  onSaved,
}: {
  kind: "owner" | "admin";
  getToken: () => string;
  onSaved?: (b: Branding) => void;
}) {
  const [b, setB] = useState<Branding | null>(null);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState("");
  const [dirty, setDirty] = useState(false);

  const endpoint = kind === "owner" ? "/api/owner/branding" : "/api/admin/branding";

  useEffect(() => {
    (async () => {
      try {
        const r = await fetch(endpoint, { headers: { authorization: `Bearer ${getToken()}` }, cache: "no-store" });
        const j = await r.json();
        if (j.ok && j.branding) setB(j.branding);
      } catch {}
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function set<K extends keyof Branding>(k: K, v: string) {
    setB((prev) => (prev ? { ...prev, [k]: v } : prev));
    setDirty(true);
    setMsg("");
  }

  async function save() {
    if (!b) return;
    setSaving(true);
    setMsg("");
    try {
      const r = await fetch(endpoint, {
        method: "PUT",
        headers: { "content-type": "application/json", authorization: `Bearer ${getToken()}` },
        body: JSON.stringify(b),
      });
      const j = await r.json();
      if (!r.ok) {
        setMsg(j.error || "Gagal simpan.");
        return;
      }
      setB(j.branding);
      setDirty(false);
      setMsg("Website tersimpan — web publik ikut ganti otomatis (max 15 detik / refresh).");
      onSaved?.(j.branding);
    } catch {
      setMsg("Gagal simpan.");
    } finally {
      setSaving(false);
    }
  }

  if (!b) {
    return (
      <div className="panel" style={{ marginBottom: 14 }}>
        <div className="panel-body" style={{ fontSize: 12.5, color: "#8a99b9" }}>Memuat setting website...</div>
      </div>
    );
  }

  return (
    <div className="panel" style={{ marginBottom: 14, borderColor: "rgba(168,85,247,0.35)" }}>
      <div className="panel-head">
        <i className="fa-solid fa-paintbrush" style={{ color: "#c084fc" }} />
        <div>
          <div className="panel-title">🎨 Nama Website & Hero — Bisa Map Apa Pun (Bukan Cuma Condo)</div>
          <div className="panel-sub">Ganti nama web + hero. Tersimpan per akun, web publik auto-update.</div>
        </div>
        {dirty && <span className="badge badge-amber" style={{ marginLeft: "auto" }}>• Belum tersimpan</span>}
      </div>
      <div className="panel-body" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(220px,1fr))", gap: 10 }}>
        <div><label style={{ fontSize: 11, fontWeight: 800, color: "#8a99b9" }}>NAMA WEB (KATA 1, PUTIH)</label><input className="field" style={{ marginTop: 6 }} value={b.siteName1} onChange={(e) => set("siteName1", e.target.value)} placeholder="CONDO" /></div>
        <div><label style={{ fontSize: 11, fontWeight: 800, color: "#8a99b9" }}>NAMA WEB (KATA 2, GRADASI)</label><input className="field" style={{ marginTop: 6 }} value={b.siteName2} onChange={(e) => set("siteName2", e.target.value)} placeholder="GAMES" /></div>
        <div><label style={{ fontSize: 11, fontWeight: 800, color: "#8a99b9" }}>JUDUL HERO</label><input className="field" style={{ marginTop: 6 }} value={b.heroTitle} onChange={(e) => set("heroTitle", e.target.value)} placeholder="Brookhaven Private" /></div>
        <div><label style={{ fontSize: 11, fontWeight: 800, color: "#8a99b9" }}>SUBJUDUL HERO</label><input className="field" style={{ marginTop: 6 }} value={b.heroSubtitle} onChange={(e) => set("heroSubtitle", e.target.value)} placeholder="Pilih server favoritmu..." /></div>
        <div><label style={{ fontSize: 11, fontWeight: 800, color: "#8a99b9" }}>JUDUL SECTION</label><input className="field" style={{ marginTop: 6 }} value={b.sectionTitle} onChange={(e) => set("sectionTitle", e.target.value)} placeholder="Private Servers" /></div>
        <div><label style={{ fontSize: 11, fontWeight: 800, color: "#8a99b9" }}>NAMA AVATAR HERO</label><input className="field" style={{ marginTop: 6 }} value={b.heroAvatarName} onChange={(e) => set("heroAvatarName", e.target.value)} placeholder="Map_Owner" /></div>
        <div style={{ gridColumn: "1/-1" }}><label style={{ fontSize: 11, fontWeight: 800, color: "#8a99b9" }}>VIDEO HERO (MP4 URL)</label><input className="field" style={{ marginTop: 6, fontSize: 12 }} value={b.heroVideo} onChange={(e) => set("heroVideo", e.target.value)} placeholder="https://...mp4" /></div>
        <div style={{ gridColumn: "1/-1" }}><label style={{ fontSize: 11, fontWeight: 800, color: "#8a99b9" }}>AVATAR HERO (IMAGE URL)</label><input className="field" style={{ marginTop: 6, fontSize: 12 }} value={b.heroAvatar} onChange={(e) => set("heroAvatar", e.target.value)} placeholder="https://..." /></div>
        <div style={{ gridColumn: "1/-1", display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
          <button className="btn-primary" style={{ flex: 1 }} disabled={saving} onClick={save}>{saving ? "Menyimpan..." : "💾 Simpan Website"}</button>
        </div>
        {msg && <div style={{ gridColumn: "1/-1", fontSize: 12.5, color: msg.includes("Gagal") ? "#fca5a5" : "#6ee7b7" }}>{msg}</div>}
        <div style={{ gridColumn: "1/-1", fontSize: 11.5, color: "#6b7a99" }}>
          Contoh map lain: Blox Fruits, Brookhaven, Doors, Pet Simulator — cukup ganti nama + link server, address auto-switch ikut Link 2 baru otomatis.
        </div>
      </div>
    </div>
  );
}
