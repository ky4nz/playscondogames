"use client";

import { useState } from "react";

type ServerLite = {
  slot: number;
  title: string;
  decoy1: string;
  decoy2: string;
  realUrl: string;
  isActive: boolean;
};

type Props = {
  kind: "owner" | "admin";
  tenantSlug?: string;
  tenantLabel?: string;
  servers: ServerLite[];
  onCopy: (text: string, label?: string) => void;
};

// Kartu "Website Saya" — tiap Owner/Admin dapat link web sendiri sesuai link server miliknya.
// Anti-tabrakan: link selalu mengandung tenant masing-masing, tidak pernah pakai web orang lain.
export default function MyWebsiteCard({ kind, tenantSlug = "", tenantLabel = "", servers, onCopy }: Props) {
  const [qrOpen, setQrOpen] = useState(false);
  const origin = typeof window !== "undefined" ? window.location.origin : "";
  const mainPath = kind === "owner" ? "/" : `/r/${tenantSlug}`;
  const mainUrl = origin + mainPath;

  const two = servers.filter((s) => s.slot === 1 || s.slot === 2).sort((a, b) => a.slot - b.slot);
  const perServer = two.map((s) => {
    const c = [(s.decoy1 || "").trim(), (s.decoy2 || "").trim(), (s.realUrl || "").trim()].filter(Boolean).length;
    const sep = mainPath.includes("?") ? "&" : "?";
    return { slot: s.slot, title: s.title, count: c, ok: c === 3 && s.isActive, active: s.isActive, url: `${mainUrl}${sep}server=${s.slot}` };
  });
  const ready = perServer.filter((p) => p.ok).length;

  const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=180x180&margin=8&color=111827&bgcolor=ffffff&data=${encodeURIComponent(mainUrl)}`;

  return (
    <div className="panel" style={{ borderColor: "rgba(16,185,129,0.45)", marginBottom: 14 }}>
      <div className="panel-head">
        <i className="fa-solid fa-globe" style={{ color: "#6ee7b7" }} />
        <div>
          <div className="panel-title">
            🌐 Website {kind === "owner" ? "Owner" : "Saya"} — Link Pribadi Anti-Tabrakan
          </div>
          <div className="panel-sub">
            {kind === "owner"
              ? "Berisi link server milik Owner saja. Penyewa punya web sendiri (/r/...) — tidak saling mengubah."
              : `Berisi link server milik ${tenantLabel || tenantSlug} saja. Bukan web Owner/orang lain — tidak akan tertukar.`}
          </div>
        </div>
        <span className={`badge ${ready === perServer.length && ready > 0 ? "badge-green" : "badge-amber"}`} style={{ marginLeft: "auto" }}>
          {ready}/{perServer.length} server siap
        </span>
      </div>
      <div className="panel-body">
        <div style={{ fontSize: 11, fontWeight: 800, color: "#8a99b9" }}>LINK WEB UTAMA {kind === "admin" ? "(BAGIKAN INI KE PEMAINMU)" : ""}</div>
        <div style={{ fontFamily: "monospace", fontSize: 13, background: "#000", padding: "10px 12px", borderRadius: 8, marginTop: 6, wordBreak: "break-all", border: "1px solid rgba(16,185,129,0.3)" }}>
          {mainUrl || mainPath}
        </div>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginTop: 10 }}>
          <button className="btn-ghost" onClick={() => onCopy(mainUrl, "Link website tersalin!")}>Salin Link Web</button>
          <button className="btn-ghost" onClick={() => window.open(mainPath, "_blank")}>Buka Website</button>
          <button className="btn-ghost" onClick={() => setQrOpen((v) => !v)}>{qrOpen ? "Sembunyi QR" : "Tampilkan QR"}</button>
        </div>
        {qrOpen && (
          <div style={{ marginTop: 12, display: "flex", gap: 14, alignItems: "center", background: "#fff", borderRadius: 12, padding: 12, maxWidth: 340 }}>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={qrUrl} alt="QR website" width={120} height={120} style={{ borderRadius: 8 }} />
            <div style={{ fontSize: 12, color: "#334155" }}>
              Scan untuk buka web ini.<br />
              <b>{kind === "owner" ? "Web Owner" : tenantLabel || tenantSlug}</b>
            </div>
          </div>
        )}

        <div style={{ marginTop: 14, fontSize: 11, fontWeight: 800, color: "#8a99b9" }}>LINK WEB PER SERVER (LANGSUNG BUKA SERVER)</div>
        <div style={{ display: "flex", flexDirection: "column", gap: 8, marginTop: 8 }}>
          {perServer.map((p) => (
            <div key={p.slot} style={{ display: "flex", flexWrap: "wrap", gap: 8, alignItems: "center", background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 10, padding: "9px 12px" }}>
              <span className="badge badge-purple">SERVER 0{p.slot}</span>
              <span style={{ fontSize: 12, fontWeight: 700 }}>{p.title}</span>
              {p.ok ? (
                <span className="badge badge-green">SIAP • 3/3</span>
              ) : (
                <span className="badge badge-amber">{p.count}/3 link{p.active ? "" : " • nonaktif"}</span>
              )}
              <span style={{ fontFamily: "monospace", fontSize: 11, color: "#8a99b9", flex: 1, minWidth: 180, wordBreak: "break-all" }}>{p.url}</span>
              <button className="btn-ghost" style={{ padding: "5px 10px", fontSize: 11 }} onClick={() => onCopy(p.url, `Link web Server 0${p.slot} tersalin!`)}>Salin</button>
              <button className="btn-ghost" style={{ padding: "5px 10px", fontSize: 11 }} onClick={() => window.open(p.url, "_blank")}>Buka</button>
            </div>
          ))}
        </div>
        <div style={{ fontSize: 11.5, color: "#6b7a99", marginTop: 10, lineHeight: 1.6 }}>
          Setiap admin/penyewa memakai <b>jalur tenant sendiri</b> — menyimpan link di sini hanya mengubah web milikmu, tidak menyentuh web Owner/admin lain.
        </div>
      </div>
    </div>
  );
}
