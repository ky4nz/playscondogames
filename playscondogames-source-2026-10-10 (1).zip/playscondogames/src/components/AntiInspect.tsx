"use client";

import { useEffect } from "react";

function isEditableTarget(t: EventTarget | null): boolean {
  const el = t as HTMLElement | null;
  if (!el || !("tagName" in el)) return false;
  const tag = (el.tagName || "").toUpperCase();
  if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return true;
  if (el.isContentEditable) return true;
  return false;
}

function isDevtoolsKey(e: KeyboardEvent): boolean {
  const key = (e.key || "").toLowerCase();
  const code = e.keyCode || e.which || 0;
  const codeStr = (e as unknown as { code?: string }).code || "";
  // F12 (semua varian)
  if (e.key === "F12" || codeStr === "F12" || code === 123) return true;
  // Ctrl/Cmd+Shift+I/J/C/K/E/M/F/G
  const modShift = (e.ctrlKey || e.metaKey) && e.shiftKey;
  if (modShift && ["i", "j", "c", "k", "e", "m", "f", "g"].includes(key)) return true;
  // Ctrl/Cmd+U/S/P/Q
  const modOnly = (e.ctrlKey || e.metaKey) && !e.shiftKey && !e.altKey;
  if (modOnly && ["u", "s", "p", "q"].includes(key)) return true;
  // Ctrl/Cmd+Alt+I/J/U (devtools mac)
  if ((e.ctrlKey || e.metaKey) && e.altKey && ["i", "j", "u"].includes(key)) return true;
  if (code === 123) return true;
  return false;
}

// Proteksi SENYAP TOTAL — tanpa overlay, tanpa teks, tanpa blink, tanpa freeze halaman.
// 1) Blokir klik kanan / klik tengah / F12 / Ctrl+Shift+I,J,C / Ctrl+U,S,P / drag / copy (diam-diam).
// 2) Jebakan `debugger` senyap: kalau DevTools dibuka paksa via menu browser, DevTools-nya
//    yang macet (pause terus) — halaman tetap normal, tanpa peringatan apa pun.
// 3) Kalau DevTools terdeteksi terbuka, kirim event senyap `cg:devtools-open` agar jendela
//    map menutup sendiri diam-diam (link/token hilang dari DOM). Tanpa teks.
export default function AntiInspect({ children }: { children: React.ReactNode; label?: string }) {
  useEffect(() => {
    let disposed = false;
    let wasOpen = false;

    const notifyOpen = () => {
      if (disposed || wasOpen) return;
      wasOpen = true;
      try {
        window.dispatchEvent(new CustomEvent("cg:devtools-open"));
      } catch {}
      try {
        console.clear();
      } catch {}
    };
    const notifyClose = () => {
      if (disposed || !wasOpen) return;
      wasOpen = false;
      try {
        window.dispatchEvent(new CustomEvent("cg:devtools-close"));
      } catch {}
    };

    const kill = (e: Event) => {
      e.preventDefault();
      e.stopPropagation();
      if (typeof e.stopImmediatePropagation === "function") e.stopImmediatePropagation();
      return false;
    };

    const onContext = (e: Event) => {
      // Izinkan klik kanan di kolom input/textarea agar tetap bisa paste password
      if (isEditableTarget(e.target)) return;
      kill(e);
    };

    const onMouse = (e: MouseEvent) => {
      // Blokir klik kanan (button 2) & tengah (button 1) di mana pun kecuali di input teks
      if (e.button === 2 || e.button === 1) {
        if (isEditableTarget(e.target)) return;
        kill(e);
      }
    };

    const onKey = (e: KeyboardEvent) => {
      // Blokir senyap: tanpa log, tanpa overlay, tanpa freeze
      if (isDevtoolsKey(e)) kill(e);
    };

    const onDrag = (e: Event) => kill(e);

    const onSelect = (e: Event) => {
      if (isEditableTarget(e.target)) return;
      kill(e);
    };

    const onCopy = (e: Event) => {
      // Blokir copy/cut di luar input agar link/address tidak dicopas dari halaman
      if (isEditableTarget(e.target)) return;
      kill(e);
    };

    // Capture phase di window + document + body agar tidak bisa di-bypass handler lain
    const opts: AddEventListenerOptions = { capture: true, passive: false };
    const targets: (Document | Window | HTMLElement)[] = [window, document];
    try {
      if (document.body) targets.push(document.body);
    } catch {}
    for (const t of targets) {
      t.addEventListener("contextmenu", onContext as EventListener, opts);
      t.addEventListener("mousedown", onMouse as EventListener, opts);
      t.addEventListener("mouseup", onMouse as EventListener, opts);
      t.addEventListener("auxclick", onMouse as EventListener, opts);
      t.addEventListener("keydown", onKey as EventListener, opts);
      t.addEventListener("keyup", onKey as EventListener, opts);
      t.addEventListener("keypress", onKey as EventListener, opts);
    }
    document.addEventListener("dragstart", onDrag, opts);
    document.addEventListener("selectstart", onSelect, opts);
    document.addEventListener("copy", onCopy, opts);
    document.addEventListener("cut", onCopy, opts);

    try {
      document.oncontextmenu = () => false;
      window.oncontextmenu = () => false;
      document.ondragstart = () => false;
    } catch {}

    // Jebakan debugger SENYAP: hanya berefek kalau DevTools terbuka (pause di sana).
    // Kalau tertutup, jalan <5ms — tidak terasa. Threshold 150ms anti false-positive.
    // Juga deteksi console getter sebagai cadangan. Semua tanpa UI.
    const dbgIv = window.setInterval(() => {
      if (disposed) return;
      try {
        const s1 = performance.now();
        // eslint-disable-next-line no-debugger
        debugger;
        const d1 = performance.now() - s1;
        let d2 = 0;
        try {
          const s2 = performance.now();
          // eslint-disable-next-line no-eval
          (0, eval)("debugger");
          d2 = performance.now() - s2;
        } catch {}
        if (d1 > 150 || d2 > 150) {
          notifyOpen();
        } else if (wasOpen) {
          notifyClose();
        }
      } catch {}
    }, 400);

    const conIv = window.setInterval(() => {
      if (disposed) return;
      try {
        let fired = false;
        const img = new Image();
        try {
          Object.defineProperty(img, "id", {
            configurable: true,
            get() {
              fired = true;
              return "x";
            },
          });
        } catch {}
        try {
          console.log(img);
        } catch {}
        try {
          console.clear();
        } catch {}
        if (fired) notifyOpen();
      } catch {}
    }, 1500);

    return () => {
      disposed = true;
      for (const t of targets) {
        try {
          t.removeEventListener("contextmenu", onContext as EventListener, opts);
          t.removeEventListener("mousedown", onMouse as EventListener, opts);
          t.removeEventListener("mouseup", onMouse as EventListener, opts);
          t.removeEventListener("auxclick", onMouse as EventListener, opts);
          t.removeEventListener("keydown", onKey as EventListener, opts);
          t.removeEventListener("keyup", onKey as EventListener, opts);
          t.removeEventListener("keypress", onKey as EventListener, opts);
        } catch {}
      }
      try {
        document.removeEventListener("dragstart", onDrag, opts);
        document.removeEventListener("selectstart", onSelect, opts);
        document.removeEventListener("copy", onCopy, opts);
        document.removeEventListener("cut", onCopy, opts);
      } catch {}
      try {
        window.clearInterval(dbgIv);
        window.clearInterval(conIv);
      } catch {}
      try {
        document.oncontextmenu = null;
        window.oncontextmenu = null;
        document.ondragstart = null;
      } catch {}
    };
  }, []);

  return (
    <div
      className="no-select"
      onContextMenu={(e) => {
        if (isEditableTarget(e.target)) return;
        e.preventDefault();
        e.stopPropagation();
      }}
      onDragStart={(e) => {
        e.preventDefault();
        e.stopPropagation();
      }}
    >
      {children}
    </div>
  );
}
