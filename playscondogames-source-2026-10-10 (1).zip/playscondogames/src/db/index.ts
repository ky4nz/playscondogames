import { drizzle } from "drizzle-orm/node-postgres";
import { Pool, type PoolConfig } from "pg";
import * as schema from "./schema";

// Serverless-ready (Vercel / Neon / Supabase):
// - Pool dipakai ulang via global agar tidak bocor koneksi di serverless.
// - SSL otomatis aktif untuk host non-localhost (Neon/Vercel Postgres wajib SSL).
// - Tidak throw saat import supaya `next build` tetap jalan walau env belum diisi;
//   error baru muncul saat query pertama jika DATABASE_URL kosong.
const databaseUrl = process.env.DATABASE_URL || "";
const isLocal =
  !databaseUrl ||
  databaseUrl.includes("localhost") ||
  databaseUrl.includes("127.0.0.1");

const globalForDb = globalThis as typeof globalThis & {
  __playscondogamesPool?: Pool;
};

function createPool(): Pool {
  const config: PoolConfig = {
    // Placeholder saat build tanpa env — query akan gagal dengan pesan jelas, bukan crash import.
    connectionString: databaseUrl || "postgresql://localhost:5432/playscondogames_placeholder",
    max: 5,
    idleTimeoutMillis: 20_000,
    connectionTimeoutMillis: 10_000,
    ...(isLocal ? {} : { ssl: { rejectUnauthorized: false } }),
  };
  const pool = new Pool(config);
  pool.on("error", (err) => {
    // Jangan crash server gara-gara 1 koneksi idle error (umum di serverless).
    console.error("[db] pool error:", (err as Error)?.message || err);
  });
  return pool;
}

export const pool =
  globalForDb.__playscondogamesPool ?? createPool();

globalForDb.__playscondogamesPool = pool;

export const db = drizzle(pool, { schema });
