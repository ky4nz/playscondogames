import {
  pgTable,
  uuid,
  text,
  timestamp,
  boolean,
  integer,
} from "drizzle-orm/pg-core";

// ─── Tenants = Admin / Penyewa ───
export const tenants = pgTable("tenants", {
  id: uuid("id").defaultRandom().primaryKey(),
  slug: text("slug").notNull().unique(),
  label: text("label").notNull(),
  passwordHash: text("password_hash").notNull(),
  passwordPlain: text("password_plain").notNull(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  isActive: boolean("is_active").notNull().default(true),
  lastLoginAt: timestamp("last_login_at", { withTimezone: true }),
  loginCount: integer("login_count").notNull().default(0),
  note: text("note").default(""),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

// ─── Server slots per tenant (termasuk 'owner') ───
// slot 1..3 = Server 01 / 02 / 03
// realUrl = Link Core (asli, HANYA dipakai server-side, TIDAK PERNAH redirect keluar — join 100% di dalam web)
// decoy1/decoy2 = Link Bodyguard 1 & 2 (tampil di source HTML sebagai pengecoh)
// gameBy/gameDesc/maturity = Tampilan Ruang Server di dalam web (seperti foto: judul, By, Maturity, deskripsi)
export const serverConfigs = pgTable("server_configs", {
  id: uuid("id").defaultRandom().primaryKey(),
  tenantSlug: text("tenant_slug").notNull().default("owner"),
  slot: integer("slot").notNull().default(1),
  title: text("title").notNull().default("Server 01"),
  realUrl: text("real_url").notNull().default(""),
  decoy1: text("decoy_1").notNull().default(""),
  decoy2: text("decoy_2").notNull().default(""),
  online: integer("online").notNull().default(0),
  maxOnline: integer("max_online").notNull().default(20),
  imageUrl: text("image_url").notNull().default(""),
  gameBy: text("game_by").notNull().default(""),
  gameDesc: text("game_desc").notNull().default(""),
  maturity: text("maturity").notNull().default("Moderate"),
  isActive: boolean("is_active").notNull().default(true),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const visits = pgTable("visits", {
  id: uuid("id").defaultRandom().primaryKey(),
  tenantSlug: text("tenant_slug").notNull().default("owner"),
  serverSlot: integer("server_slot").notNull().default(0),
  type: text("type").notNull().default("visit"),
  ipHash: text("ip_hash").notNull().default(""),
  ua: text("ua").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const sessions = pgTable("sessions", {
  token: text("token").primaryKey(),
  role: text("role").notNull(),
  tenantSlug: text("tenant_slug"),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const siteSettings = pgTable("site_settings", {
  key: text("key").primaryKey(),
  value: text("value").notNull().default(""),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export type Tenant = typeof tenants.$inferSelect;
export type ServerConfig = typeof serverConfigs.$inferSelect;
export type Visit = typeof visits.$inferSelect;
export type Session = typeof sessions.$inferSelect;
