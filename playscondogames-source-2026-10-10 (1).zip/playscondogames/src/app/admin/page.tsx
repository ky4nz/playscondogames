"use client";

import { useCallback, useEffect, useState } from "react";
import AntiInspect from "@/components/AntiInspect";
import MyWebsiteCard from "@/components/MyWebsiteCard";
import WebsiteBrandingCard from "@/components/WebsiteBrandingCard";

type ServerRow = {
  slot: number;
  title: string;
  realUrl: string;
  decoy1: string;
  decoy2: string;
  online: number;
  maxOnline: number;
  imageUrl: string;
  gameBy: string;
  gameDesc: string;
  maturity: string;
  isActive: boolean;
};

function getAdminToken(): string {
  if (typeof window === "undefined") return "";
  try {
    return sessionStorage.getItem("cg_admin_token") || localStorage.getItem("cg_admin_token") || "";
  } catch {
    return "";
  }
}

function authHeaders(): Record<string, string> {
  return { "content-type": "application/json", authorization: `Bearer ${getAdminToken()}` };
}

function clearAdminToken() {
  try {
    sessionStorage.removeItem("cg_admin_token");
  } catch {}
  try {
    sessionStorage.removeItem("cg_admin_slug");
  } catch {}
  try {
    localStorage.removeItem("cg_admin_token");
  } catch {}
  try {
    localStorage.removeItem("cg_admin_slug");
  } catch {}
}

export default function AdminPage() {
  const [ready, setReady] = useState(false);
  const [tab, setTab] = useState<"dash" | "servers" | "stats" | "activity">("dash");
  const [me, setMe] = useState<{ slug: string; label: string; expiresAt: string; remaining: string; loginCount: number; publicPath: string; publicQuery: string } | null>(null);
  const [servers, setServers] = useState<ServerRow[]>([]);
  const [stats, setStats] = useState<{ visitsToday: number; joinsToday: number; totalVisits: number; totalJoins: number; week: { day: string; visit: number; join: number }[]; mostCrowded: { slot: number; title: string; joins: number } | null } | null>(null);
  const [activity, setActivity] = useState<{ id: string; serverSlot: number; type: string; createdAt: string }[]>([]);
  const [msg, setMsg] = useState("");
  const [err, setErr] = useState("");
  const [warn, setWarn] = useState<string[]>([]);
  const [countdown, setCountdown] = useState("");
  const [dirtySlots, setDirtySlots] = useState<Record<number, boolean>>({});
  const [savingSlot, setSavingSlot] = useState<number | null>(null);
  const [savedAt, setSavedAt] = useState<Record<number, string>>({});
  const [srvErr, setSrvErr] = useState("");
  const [showThird, setShowThird] = useState(false);

  function markDirty(slot: number) {
    setDirtySlots((prev) => ({ ...prev, [slot]: true }));
  }

  const visibleServers = showThird ? servers : servers.filter((s) => s.slot !== 3);
  const totalLinks = visibleServers.length * 3;

  function slotHasData(s: { decoy1: string; decoy2: string; realUrl: string; isActive: boolean }): boolean {
    // Hanya link yang menentukan — isActive TIDAK ikut agar Server 03 kosong tidak memaksa tampil
    return !!(s.decoy1 || "").trim() || !!(s.decoy2 || "").trim() || !!(s.realUrl || "").trim();
  }

  const loadAll = useCallback(async (opts?: { skipServers?: boolean }) => {
    try {
      const m = await fetch("/api/admin/me", { headers: authHeaders() });
      const mj = await m.json();
      if (!m.ok) {
        if (mj.expired) {
          alert(mj.error || "Masa aktif habis.");
          clearAdminToken();
          window.location.href = "/";
          return;
        }
        window.location.href = "/";
        return;
      }
      setMe(mj.tenant);
      setReady(true);
      const [sv, st, ac] = await Promise.all([
        opts?.skipServers ? Promise.resolve(null) : fetch("/api/admin/servers", { headers: authHeaders() }).then((r) => r.json()),
        fetch("/api/admin/stats", { headers: authHeaders() }).then((r) => r.json()),
        fetch("/api/admin/activity?limit=60", { headers: authHeaders() }).then((r) => r.json()),
      ]);
      if (sv && sv.ok) {
        const list = sv.servers || [];
        const third = list.find((x: { slot: number }) => x.slot === 3);
        if (third && slotHasData(third)) setShowThird(true);
        setDirtySlots((dirty) => {
          if (!Object.values(dirty).some(Boolean)) setServers(list);
          return dirty;
        });
      }
      if (st.ok) setStats(st);
      if (ac.ok) setActivity(ac.activity);
    } catch {
      setErr("Gagal memuat data admin.");
    }
  }, []);

  useEffect(() => {
    loadAll();
    const iv = window.setInterval(() => loadAll({ skipServers: true }), 30000);
    return () => window.clearInterval(iv);
  }, [loadAll]);

  useEffect(() => {
    if (!me?.expiresAt) return;
    const tick = () => {
      const ms = new Date(me.expiresAt).getTime() - Date.now();
      if (ms <= 0) {
        setCountdown("KEDALUWARSA");
        return;
      }
      const s = Math.floor(ms / 1000);
      const d = Math.floor(s / 86400);
      const h = Math.floor((s % 86400) / 3600);
      const mi = Math.floor((s % 3600) / 60);
      const se = s % 60;
      setCountdown(d > 0 ? `${d} hari ${h} jam ${mi} mnt ${se} dtk` : h > 0 ? `${h} jam ${mi} mnt ${se} dtk` : `${mi} mnt ${se} dtk`);
    };
    tick();
    const iv = window.setInterval(tick, 1000);
    return () => window.clearInterval(iv);
  }, [me?.expiresAt]);

  const [fetchingMap, setFetchingMap] = useState<number | null>(null);

  async function autoFillMap(slot: number) {
    const row = servers.find((p) => p.slot === slot);
    if (!row) return;
    const link1 = (row.decoy1 || "").trim();
    if (!link1) {
      setSrvErr(`Isi Link 1 dulu untuk Server 0${slot}, lalu klik Ambil Map Otomatis.`);
      return;
    }
    setFetchingMap(slot);
    setSrvErr("");
    try {
      const r = await fetch("/api/admin/fetch-map", {
        method: "POST",
        headers: authHeaders(),
        body: JSON.stringify({ url: link1 }),
      });
      const j = await r.json();
      if (!r.ok) {
        setSrvErr(j.error || "Gagal ambil info map.");
        return;
      }
      const info = j.info || {};
      setServers((prev) =>
        prev.map((p) =>
          p.slot === slot
            ? {
                ...p,
                title: info.name ? `${info.name}`.slice(0, 60) : p.title,
                imageUrl: info.iconUrl || p.imageUrl,
                gameBy: info.creator || p.gameBy,
                gameDesc: info.description || p.gameDesc,
              }
            : p
        )
      );
      markDirty(slot);
      setMsg(
        info.name
          ? `Map terdeteksi: ${info.name}${info.creator ? ` by ${info.creator}` : ""} — judul + banner terisi otomatis. Klik Simpan.`
          : "Link terbaca. Klik Simpan."
      );
    } catch {
      setSrvErr("Gagal ambil info map.");
    } finally {
      setFetchingMap(null);
    }
  }

  async function saveOneServer(slot: number) {
    const row = servers.find((p) => p.slot === slot);
    if (!row) return;
    setSavingSlot(slot);
    setSrvErr("");
    setWarn([]);
    try {
      const r = await fetch("/api/admin/servers", {
        method: "PUT",
        headers: authHeaders(),
        body: JSON.stringify({
          server: { slot: row.slot, title: row.title, decoy1: row.decoy1, decoy2: row.decoy2, realUrl: row.realUrl, isActive: row.isActive, imageUrl: row.imageUrl, gameBy: row.gameBy, gameDesc: row.gameDesc, maturity: row.maturity },
        }),
      });
      const j = await r.json();
      if (!r.ok) {
        setSrvErr(j.error || `Gagal simpan Server 0${slot}.`);
        return;
      }
      if (j.warnings?.length) setWarn(j.warnings);
      if (j.servers) {
        setServers(j.servers);
        const third = j.servers.find((x: { slot: number }) => x.slot === 3);
        if (third && slotHasData(third)) setShowThird(true);
      }
      setDirtySlots((prev) => ({ ...prev, [slot]: false }));
      const now = new Date().toLocaleTimeString("id-ID");
      setSavedAt((prev) => ({ ...prev, [slot]: now }));
      setMsg(`Server 0${slot} tersimpan permanen (${now}). Tidak hilang saat refresh.`);
      if (j.incomplete?.length) setSrvErr(`Catatan: ${j.incomplete.join(" ")} (tetap tersimpan).`);
      loadAll({ skipServers: true });
    } catch {
      setSrvErr(`Gagal simpan Server 0${slot}.`);
    } finally {
      setSavingSlot(null);
    }
  }

  async function saveServers() {
    setMsg("");
    setErr("");
    setSrvErr("");
    setWarn([]);
    const toSend = visibleServers.map((row) => ({ slot: row.slot, title: row.title, decoy1: row.decoy1, decoy2: row.decoy2, realUrl: row.realUrl, isActive: row.isActive, imageUrl: row.imageUrl, gameBy: row.gameBy, gameDesc: row.gameDesc, maturity: row.maturity }));
    const r = await fetch("/api/admin/servers", {
      method: "PUT",
      headers: authHeaders(),
      body: JSON.stringify({ servers: toSend }),
    });
    const j = await r.json();
    if (!r.ok) {
      setSrvErr(j.error || "Gagal simpan.");
      return;
    }
    if (j.warnings?.length) setWarn(j.warnings);
    if (j.servers) setServers(j.servers);
    setDirtySlots({});
    const now = new Date().toLocaleTimeString("id-ID");
    const stamp: Record<number, string> = {};
    for (const s of visibleServers) stamp[s.slot] = now;
    setSavedAt((prev) => ({ ...prev, ...stamp }));
    const f = countFilled();
    setMsg(`Semua tersimpan permanen (${now}). Total ${f}/${totalLinks}. Tidak hilang saat refresh.`);
    if (j.incomplete?.length) setSrvErr(`Catatan: ${j.incomplete.join(" ")} (tetap tersimpan).`);
    loadAll({ skipServers: true });
  }

  function countFilled(): number {
    let n = 0;
    for (const s of visibleServers) {
      if ((s.decoy1 || "").trim()) n += 1;
      if ((s.decoy2 || "").trim()) n += 1;
      if ((s.realUrl || "").trim()) n += 1;
    }
    return n;
  }

  function logout() {
    fetch("/api/auth/logout", { method: "POST", headers: authHeaders() }).finally(() => {
      clearAdminToken();
      window.location.href = "/";
    });
  }

  function copy(text: string, label = "Tersalin!") {
    try {
      navigator.clipboard.writeText(text).then(() => setMsg(label));
    } catch {
      prompt("Salin manual:", text);
    }
  }

  if (!ready) {
    return <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", color: "#8a99b9" }}>Memeriksa sesi Admin...</div>;
  }

  const maxBar = Math.max(1, ...(stats?.week.map((w) => Math.max(w.visit, w.join)) || [1]));

  return (
    <AntiInspect label="ADMIN PANEL TERPROTEKSI">
      <div style={{ minHeight: "100vh", background: "#0b0914" }}>
        <header className="navbar">
          <div className="nav-brand">
            <div className="brand-icon"><i className="fa-solid fa-gem" /></div>
            <span>ADMIN <span className="grad">PANEL</span></span>
            <span className="badge badge-purple" style={{ marginLeft: 8 }}>{me?.label} • {me?.slug}</span>
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <button className="btn-ghost" onClick={() => copy(window.location.origin + (me?.publicPath || ""), "Link publik tokomu tersalin!")}>Salin Link Saya</button>
            <button className="btn-danger" onClick={logout}>Keluar</button>
          </div>
        </header>

        <div style={{ maxWidth: 1100, margin: "0 auto", padding: 16 }}>
          <div className="panel" style={{ borderColor: "rgba(16,185,129,0.4)", marginBottom: 14 }}>
            <div className="panel-body" style={{ display: "flex", flexWrap: "wrap", gap: 14, alignItems: "center" }}>
              <div style={{ flex: 1, minWidth: 240 }}>
                <div style={{ fontSize: 12, fontWeight: 800, color: "#6ee7b7" }}>🌐 WEBSITE KAMU SENDIRI (LINK MAP MILIKMU SAJA)</div>
                <div style={{ fontFamily: "monospace", fontSize: 13, background: "#000", padding: "10px 12px", borderRadius: 8, marginTop: 6, wordBreak: "break-all" }}>{typeof window !== "undefined" && me ? window.location.origin + me.publicPath : me?.publicPath}</div>
                <div style={{ fontSize: 11.5, color: "#8a99b9", marginTop: 6 }}>Web ini hanya berisi link map yang kamu input — bukan link orang lain. Bagikan link ini ke pembeli/pemainmu.</div>
                <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
                  <button className="btn-ghost" onClick={() => copy(window.location.origin + (me?.publicPath || ""), "Link website kamu tersalin!")}>Salin Link Saya</button>
                  <button className="btn-ghost" onClick={() => window.open(me?.publicPath || "/", "_blank")}>Buka Website Saya</button>
                </div>
              </div>
              <div style={{ minWidth: 200 }}>
                <div style={{ fontSize: 12, fontWeight: 800, color: "#8a99b9" }}>SISA MASA AKTIF</div>
                <div style={{ fontSize: 20, fontWeight: 800, marginTop: 4 }}>{countdown}</div>
                <div style={{ fontSize: 11.5, color: "#8a99b9", marginTop: 4 }}>Berakhir: {me?.expiresAt ? new Date(me.expiresAt).toLocaleString("id-ID") : "-"}</div>
              </div>
            </div>
          </div>

          {(msg || err) && (
            <div style={{ marginBottom: 14 }}>
              {msg && <div style={{ background: "rgba(16,185,129,0.1)", border: "1px solid rgba(16,185,129,0.3)", color: "#6ee7b7", fontSize: 13, padding: "10px 14px", borderRadius: 12 }}>{msg}</div>}
              {err && <div style={{ background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.3)", color: "#fca5a5", fontSize: 13, padding: "10px 14px", borderRadius: 12, marginTop: msg ? 8 : 0 }}>{err}</div>}
            </div>
          )}

          <div style={{ display: "grid", gridTemplateColumns: "220px 1fr", gap: 16 }}>
            <aside className="panel" style={{ alignSelf: "start" }}>
              <div className="panel-head"><i className="fa-solid fa-layer-group" style={{ color: "#a855f7" }} /><div className="panel-title">Menu Admin</div></div>
              <div className="panel-body" style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                {[
                  { k: "dash", icon: "fa-gauge-high", label: "① Dashboard Saya" },
                  { k: "servers", icon: "fa-server", label: "② Link Server 1-3" },
                  { k: "stats", icon: "fa-chart-column", label: "③ Statistik Harian" },
                  { k: "activity", icon: "fa-clock-rotate-left", label: "④ Aktivitas" },
                ].map((m) => (
                  <button key={m.k} className={`side-link ${tab === m.k ? "active" : ""}`} onClick={() => setTab(m.k as typeof tab)}>
                    <i className={`fa-solid ${m.icon}`} /> {m.label}
                  </button>
                ))}
                <div style={{ fontSize: 11, color: "#6b7a99", marginTop: 10, lineHeight: 1.6 }}>Panel ini terproteksi: klik kanan, F12, Ctrl+Shift+I, Ctrl+U/S & console diblokir agar address tidak bocor.</div>
              </div>
            </aside>

            <main style={{ display: "flex", flexDirection: "column", gap: 16, minWidth: 0 }}>
              {tab === "dash" && (
                <>
                  <div className="panel">
                    <div className="panel-head"><i className="fa-solid fa-gauge-high" style={{ color: "#a855f7" }} /><div><div className="panel-title">Panel ① — Dashboard Admin / Penyewa</div><div className="panel-sub">Visit link, join click & server paling rame milikmu sendiri.</div></div></div>
                    <div className="panel-body">
                      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(150px,1fr))", gap: 12 }}>
                        {[
                          { l: "Visit Hari Ini", v: stats?.visitsToday ?? 0 },
                          { l: "Join Hari Ini", v: stats?.joinsToday ?? 0 },
                          { l: "Total Visit (7h)", v: stats?.totalVisits ?? 0 },
                          { l: "Total Join (7h)", v: stats?.totalJoins ?? 0 },
                        ].map((c) => (
                          <div key={c.l} className="stat-card">
                            <div style={{ fontSize: 11, color: "#8a99b9", fontWeight: 700 }}>{c.l.toUpperCase()}</div>
                            <div style={{ fontSize: 26, fontWeight: 800, marginTop: 6 }}>{c.v}</div>
                          </div>
                        ))}
                      </div>
                      <div className="stat-card" style={{ marginTop: 12 }}>
                        <div style={{ fontSize: 12, fontWeight: 800 }}><i className="fa-solid fa-fire" style={{ color: "#f59e0b", marginRight: 8 }} />SERVER PALING RAME MILIKMU</div>
                        {stats?.mostCrowded ? (
                          <div style={{ marginTop: 8, fontSize: 13 }}><b style={{ fontSize: 15 }}>{stats.mostCrowded.title}</b><div style={{ color: "#8a99b9" }}>{stats.mostCrowded.joins}× join (7 hari) • Slot {stats.mostCrowded.slot}</div></div>
                        ) : (
                          <div style={{ color: "#8a99b9", fontSize: 13, marginTop: 6 }}>Belum ada join.</div>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="panel">
                    <div className="panel-head"><i className="fa-solid fa-chart-column" style={{ color: "#22d3ee" }} /><div><div className="panel-title">Grafik 7 Hari Milikmu</div><div className="panel-sub">Ungu = visit • Pink = join.</div></div></div>
                    <div className="panel-body">
                      <div className="bar-row">
                        {(stats?.week || []).map((w) => (
                          <div key={w.day} className="bar-col">
                            <div className="bar-stack">
                              <div className="bar bar-v" style={{ height: `${Math.max(3, (w.visit / maxBar) * 86)}px` }} />
                              <div className="bar bar-j" style={{ height: `${Math.max(3, (w.join / maxBar) * 86)}px` }} />
                            </div>
                            <div className="bar-day">{w.day.slice(5)}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </>
              )}

              {tab === "servers" && (
                <div className="panel">
                  <div className="panel-head"><i className="fa-solid fa-server" style={{ color: "#22d3ee" }} /><div><div className="panel-title">Panel ② — Setting Link Private Server • {visibleServers.length} Server</div><div className="panel-sub">3 link per server • Total {countFilled()}/{totalLinks} • Info map otomatis dari Roblox</div></div></div>
                  <div className="panel-body">
                    <div style={{ background: "rgba(16,185,129,0.08)", border: "1px solid rgba(16,185,129,0.35)", borderRadius: 12, padding: 12, fontSize: 12.5, color: "#cbd5e1", marginBottom: 14 }}>
                      <b>Server join ada 2</b> — cukup isi <b>3 link per server</b> (total <b>{totalLinks} link</b>). <b>Link 1 = DISPLAY</b> • <b>Link 2 = LOGIN</b> • <b>Link 3 = CORE</b> (ditutupi 1 & 2). Tersimpan permanen.<br />
                      🌐 <b>Website kamu (isi link map milikmu saja):</b> <span style={{ fontFamily: "monospace" }}>{typeof window !== "undefined" && me ? window.location.origin + me.publicPath : ""}</span>
                      {me && (
                        <>
                          <button className="btn-ghost" style={{ marginLeft: 8, padding: "4px 10px", fontSize: 11 }} onClick={() => copy(window.location.origin + me.publicPath, "Link website kamu tersalin!")}>Salin</button>
                          <button className="btn-ghost" style={{ marginLeft: 6, padding: "4px 10px", fontSize: 11 }} onClick={() => window.open(me.publicPath, "_blank")}>Buka</button>
                        </>
                      )}
                    </div>
                    {me && (
                      <MyWebsiteCard kind="admin" tenantSlug={me.slug} tenantLabel={me.label} servers={servers} onCopy={copy} />
                    )}
                    <WebsiteBrandingCard kind="admin" getToken={getAdminToken} />
                    {srvErr && (
                      <div style={{ background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.3)", color: "#fca5a5", fontSize: 12.5, padding: "10px 12px", borderRadius: 12, marginBottom: 12 }}>{srvErr}</div>
                    )}
                    {warn.length > 0 && (
                      <div style={{ background: "rgba(245,158,11,0.08)", border: "1px solid rgba(245,158,11,0.35)", borderRadius: 12, padding: 12, fontSize: 12.5, color: "#fcd34d", marginBottom: 14 }}>
                        {warn.map((w, i) => <div key={i}>⚠️ {w}</div>)}
                      </div>
                    )}
                    {visibleServers.map((s) => {
                      const c = [(s.decoy1 || "").trim(), (s.decoy2 || "").trim(), (s.realUrl || "").trim()].filter(Boolean).length;
                      const dirty = !!dirtySlots[s.slot];
                      const saving = savingSlot === s.slot;
                      return (
                      <div key={s.slot} className="panel" style={{ marginBottom: 12, borderColor: dirty ? "rgba(245,158,11,0.4)" : undefined }}>
                        <div className="panel-head">
                          <span className="badge badge-purple">SERVER 0{s.slot}</span>
                          <input className="field" style={{ maxWidth: 200 }} value={s.title} onChange={(e) => { markDirty(s.slot); setServers((prev) => prev.map((p) => (p.slot === s.slot ? { ...p, title: e.target.value } : p))); }} />
                          <span className={`badge ${c === 3 ? "badge-green" : "badge-amber"}`} style={{ marginLeft: 8 }}>{c}/3 link</span>
                          {dirty && <span className="badge badge-amber" style={{ marginLeft: 6 }}>• Belum tersimpan</span>}
                          {!dirty && savedAt[s.slot] && <span style={{ fontSize: 11, color: "#6ee7b7", marginLeft: 8 }}>✓ {savedAt[s.slot]}</span>}
                          <label style={{ marginLeft: "auto", fontSize: 12, display: "flex", gap: 6, alignItems: "center" }}><input type="checkbox" checked={s.isActive} onChange={(e) => { markDirty(s.slot); setServers((prev) => prev.map((p) => (p.slot === s.slot ? { ...p, isActive: e.target.checked } : p))); }} /> Aktif</label>
                        </div>
                        <div className="panel-body" style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                          <div><label style={{ fontSize: 11, fontWeight: 800, color: "#93c5fd" }}>LINK 1 — DISPLAY (tampil di address bar) — map apa pun</label><input className="field" style={{ marginTop: 6, fontFamily: "monospace", fontSize: 12 }} placeholder="Tempel Link 1 map apa pun di sini..." value={s.decoy1} onChange={(e) => { markDirty(s.slot); setServers((prev) => prev.map((p) => (p.slot === s.slot ? { ...p, decoy1: e.target.value } : p))); }} /></div>
                          <div><label style={{ fontSize: 11, fontWeight: 800, color: "#fcd34d" }}>LINK 2 — LOGIN (tampil otomatis saat sign in)</label><input className="field" style={{ marginTop: 6, fontFamily: "monospace", fontSize: 12 }} placeholder="Tempel Link 2 login di sini — auto-switch ikut link ini..." value={s.decoy2} onChange={(e) => { markDirty(s.slot); setServers((prev) => prev.map((p) => (p.slot === s.slot ? { ...p, decoy2: e.target.value } : p))); }} /></div>
                          <div><label style={{ fontSize: 11, fontWeight: 800, color: "#6ee7b7" }}>LINK 3 — CORE (private utama, ditutupi 1 & 2)</label><input className="field" style={{ marginTop: 6, fontFamily: "monospace", fontSize: 12 }} placeholder="Tempel Link 3 di sini..." value={s.realUrl} onChange={(e) => { markDirty(s.slot); setServers((prev) => prev.map((p) => (p.slot === s.slot ? { ...p, realUrl: e.target.value } : p))); }} /></div>
                          {s.imageUrl ? (
                            <div style={{ display: "flex", gap: 10, alignItems: "center", background: "rgba(255,255,255,0.03)", borderRadius: 10, padding: 8 }}>
                              {/* eslint-disable-next-line @next/next/no-img-element */}
                              <img src={s.imageUrl} alt="banner" style={{ width: 120, height: 68, objectFit: "cover", borderRadius: 8 }} />
                              <div style={{ fontSize: 11.5, color: "#8a99b9" }}>Banner map saat ini.<br />Judul: <b style={{ color: "#e2e8f0" }}>{s.title}</b></div>
                            </div>
                          ) : null}
                          <div><label style={{ fontSize: 11, fontWeight: 800, color: "#8a99b9" }}>BANNER MAP (otomatis / manual)</label><input className="field" style={{ marginTop: 6, fontSize: 12 }} placeholder="https://... (kosong = pakai default)" value={s.imageUrl} onChange={(e) => { markDirty(s.slot); setServers((prev) => prev.map((p) => (p.slot === s.slot ? { ...p, imageUrl: e.target.value } : p))); }} /></div>
                          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                            <button className="btn-ghost" style={{ flex: 1 }} disabled={fetchingMap === s.slot} onClick={() => autoFillMap(s.slot)}>{fetchingMap === s.slot ? "Mengambil..." : "🔄 Ambil Map Otomatis dari Link 1"}</button>
                            <button className="btn-primary" style={{ flex: 1 }} disabled={saving} onClick={() => saveOneServer(s.slot)}>{saving ? "Menyimpan..." : `💾 Simpan Server 0${s.slot} Saja`}</button>
                          </div>
                          <div style={{ fontSize: 11, color: "#6b7a99" }}>Ganti map/link kapan pun → web + auto-switch login ikut link baru otomatis.</div>
                        </div>
                      </div>
                      );
                    })}
                    {!showThird ? (
                      <button className="btn-ghost" style={{ width: "100%", marginBottom: 8 }} onClick={() => setShowThird(true)}>＋ Tampilkan Server 03 (Opsional)</button>
                    ) : (
                      <button className="btn-ghost" style={{ width: "100%", marginBottom: 8 }} onClick={() => setShowThird(false)}>－ Sembunyikan Server 03 (data tetap tersimpan)</button>
                    )}
                    <button className="btn-ghost" style={{ width: "100%" }} onClick={saveServers}>💾 Simpan Semua Sekaligus ({countFilled()}/{totalLinks})</button>
                  </div>
                </div>
              )}

              {tab === "stats" && (
                <div className="panel">
                  <div className="panel-head"><i className="fa-solid fa-chart-line" style={{ color: "#a855f7" }} /><div><div className="panel-title">Panel ③ — Statistik Harian Milikmu</div><div className="panel-sub">Per hari berapa visit + join click.</div></div></div>
                  <div className="panel-body">
                    <div className="table-wrap">
                      <table className="nice">
                        <thead><tr><th>Tanggal</th><th>Visit</th><th>Join</th><th>Total</th></tr></thead>
                        <tbody>
                          {(stats?.week || []).map((w) => (
                            <tr key={w.day}><td><b>{w.day}</b></td><td>{w.visit}</td><td>{w.join}</td><td><b>{w.visit + w.join}</b></td></tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {tab === "activity" && (
                <div className="panel">
                  <div className="panel-head"><i className="fa-solid fa-clock-rotate-left" style={{ color: "#22d3ee" }} /><div><div className="panel-title">Panel ④ — Aktivitas Pengunjungmu</div><div className="panel-sub">60 aktivitas terbaru di link publikmu.</div></div></div>
                  <div className="panel-body">
                    <div className="table-wrap">
                      <table className="nice">
                        <thead><tr><th>Waktu</th><th>Server</th><th>Tipe</th></tr></thead>
                        <tbody>
                          {activity.map((r) => (
                            <tr key={r.id}><td>{new Date(r.createdAt).toLocaleString("id-ID")}</td><td>{r.serverSlot === 0 ? "Halaman" : `Server 0${r.serverSlot}`}</td><td>{r.type === "join" ? <span className="badge badge-purple">JOIN</span> : <span className="badge badge-green">VISIT</span>}</td></tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}
            </main>
          </div>
          <style>{`@media(max-width:900px){div[style*="grid-template-columns: 220px 1fr"]{grid-template-columns:1fr !important;}}`}</style>
        </div>
      </div>
    </AntiInspect>
  );
}
