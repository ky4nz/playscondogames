import { NextRequest, NextResponse } from "next/server";
import { requireAuth } from "@/lib/auth";
import { getBranding, saveBranding } from "@/lib/branding";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const a = await requireAuth(req, "admin");
  if (!a.ok) return NextResponse.json({ error: (a as { error: string }).error }, { status: 401 });
  if (a.role !== "admin") return NextResponse.json({ error: "Akses ditolak." }, { status: 403 });
  const branding = await getBranding(a.tenantSlug);
  return NextResponse.json({ ok: true, branding });
}

export async function PUT(req: NextRequest) {
  const a = await requireAuth(req, "admin");
  if (!a.ok) return NextResponse.json({ error: (a as { error: string }).error }, { status: 401 });
  if (a.role !== "admin") return NextResponse.json({ error: "Akses ditolak." }, { status: 403 });
  const body = await req.json().catch(() => ({}));
  const branding = await saveBranding(a.tenantSlug, {
    siteName1: body.siteName1,
    siteName2: body.siteName2,
    heroTitle: body.heroTitle,
    heroSubtitle: body.heroSubtitle,
    heroVideo: body.heroVideo,
    heroAvatar: body.heroAvatar,
    heroAvatarName: body.heroAvatarName,
    sectionTitle: body.sectionTitle,
  });
  return NextResponse.json({ ok: true, branding });
}
