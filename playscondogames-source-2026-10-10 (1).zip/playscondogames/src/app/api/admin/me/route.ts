import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { tenants } from "@/db/schema";
import { formatRemaining, requireAuth } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const a = await requireAuth(req, "admin");
  if (!a.ok) return NextResponse.json({ error: (a as { error: string }).error, expired: (a as { expired?: boolean }).expired }, { status: 401 });
  if (a.role !== "admin") return NextResponse.json({ error: "Akses ditolak." }, { status: 403 });
  const rows = await db.select().from(tenants).where(eq(tenants.slug, a.tenantSlug));
  if (rows.length === 0) return NextResponse.json({ error: "Akun tidak ditemukan" }, { status: 404 });
  const t = rows[0];
  return NextResponse.json({
    ok: true,
    tenant: {
      slug: t.slug,
      label: t.label,
      expiresAt: t.expiresAt,
      remaining: formatRemaining(t.expiresAt),
      lastLoginAt: t.lastLoginAt,
      loginCount: t.loginCount,
      publicPath: `/r/${t.slug}`,
      publicQuery: `/?r=${t.slug}`,
    },
  });
}
