import { NextRequest, NextResponse } from "next/server";
import { and, desc, eq, gte, sql } from "drizzle-orm";
import { db } from "@/db";
import { serverConfigs, visits } from "@/db/schema";
import { requireAuth } from "@/lib/auth";

export const dynamic = "force-dynamic";

function dayKey(d: Date): string {
  return d.toISOString().slice(0, 10);
}

export async function GET(req: NextRequest) {
  const a = await requireAuth(req, "admin");
  if (!a.ok) return NextResponse.json({ error: (a as { error: string }).error }, { status: 401 });
  if (a.role !== "admin") return NextResponse.json({ error: "Akses ditolak." }, { status: 403 });
  const slug = a.tenantSlug;

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const todayRows = await db.select().from(visits).where(and(eq(visits.tenantSlug, slug), gte(visits.createdAt, today)));
  const visitsToday = todayRows.filter((r) => r.type === "visit").length;
  const joinsToday = todayRows.filter((r) => r.type === "join").length;

  const since = new Date();
  since.setDate(since.getDate() - 6);
  since.setHours(0, 0, 0, 0);
  const weekRows = await db.select().from(visits).where(and(eq(visits.tenantSlug, slug), gte(visits.createdAt, since)));

  const byDay: Record<string, { visit: number; join: number }> = {};
  for (let i = 0; i < 7; i++) {
    const d = new Date(since);
    d.setDate(since.getDate() + i);
    byDay[dayKey(d)] = { visit: 0, join: 0 };
  }
  for (const r of weekRows) {
    const k = dayKey(new Date(r.createdAt));
    if (!byDay[k]) byDay[k] = { visit: 0, join: 0 };
    if (r.type === "join") byDay[k].join += 1;
    else byDay[k].visit += 1;
  }
  const week = Object.entries(byDay).map(([day, v]) => ({ day, ...v }));
  const totalVisits = weekRows.filter((r) => r.type === "visit").length;
  const totalJoins = weekRows.filter((r) => r.type === "join").length;

  const joinGroups = await db
    .select({ serverSlot: visits.serverSlot, c: sql<number>`count(*)` })
    .from(visits)
    .where(and(eq(visits.tenantSlug, slug), gte(visits.createdAt, since), eq(visits.type, "join")))
    .groupBy(visits.serverSlot)
    .orderBy(desc(sql`count(*)`))
    .limit(3);

  let mostCrowded: { slot: number; title: string; joins: number } | null = null;
  if (joinGroups.length > 0) {
    const g = joinGroups[0];
    const cfg = await db.select().from(serverConfigs).where(and(eq(serverConfigs.tenantSlug, slug), eq(serverConfigs.slot, g.serverSlot)));
    mostCrowded = { slot: g.serverSlot, title: cfg[0]?.title || `Server 0${g.serverSlot}`, joins: Number(g.c) };
  }

  return NextResponse.json({ ok: true, visitsToday, joinsToday, totalVisits, totalJoins, week, mostCrowded });
}
