import { NextRequest, NextResponse } from "next/server";
import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { visits } from "@/db/schema";
import { requireAuth } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const a = await requireAuth(req, "admin");
  if (!a.ok) return NextResponse.json({ error: (a as { error: string }).error }, { status: 401 });
  if (a.role !== "admin") return NextResponse.json({ error: "Akses ditolak." }, { status: 403 });
  const url = new URL(req.url);
  const limit = Math.min(Math.max(Number(url.searchParams.get("limit")) || 60, 1), 200);
  const rows = await db
    .select()
    .from(visits)
    .where(eq(visits.tenantSlug, a.tenantSlug))
    .orderBy(desc(visits.createdAt))
    .limit(limit);
  void and;
  return NextResponse.json({ ok: true, activity: rows });
}
