import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { tenants } from "@/db/schema";
import { formatRemaining, requireAuth } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const a = await requireAuth(req, "any");
  if (!a.ok) return NextResponse.json({ error: (a as { error: string }).error }, { status: 401 });
  if (a.role === "owner") return NextResponse.json({ ok: true, role: "owner" });
  const rows = await db.select().from(tenants).where(eq(tenants.slug, a.tenantSlug));
  if (rows.length === 0) return NextResponse.json({ error: "Tenant tidak ada" }, { status: 404 });
  const t = rows[0];
  return NextResponse.json({
    ok: true,
    role: "admin",
    tenant: {
      slug: t.slug,
      label: t.label,
      expiresAt: t.expiresAt,
      remaining: formatRemaining(t.expiresAt),
      lastLoginAt: t.lastLoginAt,
      loginCount: t.loginCount,
      isActive: t.isActive,
    },
  });
}
