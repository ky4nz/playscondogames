import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { sessions, tenants } from "@/db/schema";
import {
  autoResetTenant,
  checkRateLimit,
  generateToken,
  getClientIp,
  hashPassword,
} from "@/lib/auth";
import { ensureDefaults } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  await ensureDefaults();
  const ip = getClientIp(req);
  const rl = checkRateLimit(`admin:${ip}`, 8, 60_000);
  if (!rl.allowed) {
    return NextResponse.json({ error: `Terlalu banyak percobaan. Tunggu ${rl.retryAfterSec} detik (anti tebak password).` }, { status: 429 });
  }
  const body = await req.json().catch(() => ({}));
  const password = String(body.password || "");
  if (!password) return NextResponse.json({ error: "Password wajib diisi." }, { status: 400 });

  // 1 password -> 1 tenant sendiri. Cari tenant yang hash-nya cocok.
  const h = hashPassword(password);
  const rows = await db.select().from(tenants).where(eq(tenants.passwordHash, h));
  if (rows.length === 0) {
    return NextResponse.json({ error: "Password tidak dikenali. Minta password resmi dari Owner — dilarang menebak." }, { status: 401 });
  }
  const tenant = rows[0];
  const now = Date.now();
  if (!tenant.isActive || new Date(tenant.expiresAt).getTime() < now) {
    await autoResetTenant(tenant.slug);
    return NextResponse.json({ error: "Masa aktif password ini HABIS. Link Server 1/2/3 otomatis di-reset. Hubungi Owner untuk perpanjang.", expired: true }, { status: 403 });
  }

  const token = generateToken();
  const sessionExp = Math.min(Date.now() + 12 * 3600 * 1000, new Date(tenant.expiresAt).getTime());
  await db.insert(sessions).values({ token, role: "admin", tenantSlug: tenant.slug, expiresAt: new Date(sessionExp) });
  await db.update(tenants).set({ lastLoginAt: new Date(), loginCount: (tenant.loginCount || 0) + 1 }).where(eq(tenants.slug, tenant.slug));

  return NextResponse.json({
    ok: true,
    token,
    expiresAt: new Date(sessionExp),
    tenant: { slug: tenant.slug, label: tenant.label, expiresAt: tenant.expiresAt },
  });
}
