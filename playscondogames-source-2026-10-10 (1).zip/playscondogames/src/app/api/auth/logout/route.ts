import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { sessions } from "@/db/schema";
import { getBearerToken } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  const token = getBearerToken(req);
  if (token) await db.delete(sessions).where(eq(sessions.token, token)).catch(() => {});
  return NextResponse.json({ ok: true });
}
