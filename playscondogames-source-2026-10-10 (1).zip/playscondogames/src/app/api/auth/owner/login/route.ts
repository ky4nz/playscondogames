import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { sessions } from "@/db/schema";
import { checkRateLimit, generateToken, getClientIp, verifyOwnerPassword } from "@/lib/auth";
import { ensureDefaults } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  await ensureDefaults();
  const ip = getClientIp(req);
  const rl = checkRateLimit(`owner:${ip}`, 8, 60_000);
  if (!rl.allowed) {
    return NextResponse.json({ error: `Terlalu banyak percobaan. Tunggu ${rl.retryAfterSec} detik (anti tebak password).` }, { status: 429 });
  }
  const body = await req.json().catch(() => ({}));
  const password = String(body.password || "");
  if (!password) return NextResponse.json({ error: "Password wajib diisi." }, { status: 400 });

  const ok = await verifyOwnerPassword(password);
  if (!ok) {
    return NextResponse.json({ error: "Password Owner salah. Jangan asal tebak — tersisa percobaan terbatas." }, { status: 401 });
  }
  const token = generateToken();
  const expiresAt = new Date(Date.now() + 12 * 3600 * 1000);
  await db.insert(sessions).values({ token, role: "owner", expiresAt });
  return NextResponse.json({ ok: true, token, expiresAt });
}
