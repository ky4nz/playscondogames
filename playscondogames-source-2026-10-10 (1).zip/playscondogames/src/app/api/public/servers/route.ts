import { NextRequest, NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { serverConfigs, tenants, visits } from "@/db/schema";
import { getClientIp, hashIp, sweepExpiredTenants } from "@/lib/auth";
import { ensureDefaults, ensureTenantServers } from "@/lib/seed";
import { getBranding } from "@/lib/branding";

export const dynamic = "force-dynamic";

// Publik: daftar server TANPA URL apa pun + branding web (bisa map apa pun, bukan cuma condo).
export async function GET(req: NextRequest) {
  await ensureDefaults();
  await sweepExpiredTenants().catch(() => {});

  const url = new URL(req.url);
  let slug = (url.searchParams.get("r") || "owner").trim() || "owner";
  if (slug.length > 64) slug = "owner";

  let label = "Condo Games";

  if (slug !== "owner") {
    const t = await db.select().from(tenants).where(eq(tenants.slug, slug));
    if (t.length === 0) {
      return NextResponse.json({ error: "Link penyewa tidak valid." }, { status: 404 });
    }
    const tenant = t[0];
    if (!tenant.isActive || new Date(tenant.expiresAt).getTime() < Date.now()) {
      return NextResponse.json({ error: "Link penyewa kedaluwarsa. Hubungi Owner.", expired: true }, { status: 410 });
    }
    label = tenant.label || slug;
    await ensureTenantServers(slug);
  }

  const rows = await db
    .select()
    .from(serverConfigs)
    .where(and(eq(serverConfigs.tenantSlug, slug), eq(serverConfigs.isActive, true)));

  const sorted = rows.sort((a, b) => a.slot - b.slot).map((r) => {
    const link1 = (r.decoy1 || "").trim();
    const link2 = (r.decoy2 || "").trim();
    const link3 = (r.realUrl || "").trim();
    const complete = !!link1 && !!link2 && !!link3;
    return {
      slot: r.slot,
      title: r.title,
      online: r.online,
      maxOnline: r.maxOnline,
      imageUrl: r.imageUrl,
      gameBy: r.gameBy || "",
      gameDesc: r.gameDesc || "",
      maturity: r.maturity || "",
      isActive: r.isActive,
      linksComplete: complete,
      linksCount: [link1, link2, link3].filter(Boolean).length,
      roomPath: `/server/${r.slot}`,
      updatedAt: r.updatedAt,
    };
  });

  const branding = await getBranding(slug).catch(() => null);

  try {
    const ip = getClientIp(req);
    await db.insert(visits).values({
      tenantSlug: slug,
      serverSlot: 0,
      type: "visit",
      ipHash: hashIp(ip + new Date().toDateString().slice(0, 10)),
      ua: (req.headers.get("user-agent") || "").slice(0, 180),
    });
  } catch {}

  return NextResponse.json({ ok: true, tenantSlug: slug, label, servers: sorted, branding, active: true });
}
