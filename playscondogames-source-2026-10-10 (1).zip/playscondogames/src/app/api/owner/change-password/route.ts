import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { siteSettings } from "@/db/schema";
import { getOwnerPasswordHash, hashPassword, requireAuth, verifyPassword } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  const a = await requireAuth(req, "owner");
  if (!a.ok) return NextResponse.json({ error: (a as { error: string }).error }, { status: 401 });
  const body = await req.json().catch(() => ({}));
  const oldPwd = String(body.oldPassword || "");
  const newPwd = String(body.newPassword || "");
  if (!oldPwd || !newPwd) return NextResponse.json({ error: "Password lama & baru wajib diisi." }, { status: 400 });
  if (newPwd.length < 8) return NextResponse.json({ error: "Password baru minimal 8 karakter." }, { status: 400 });
  const stored = await getOwnerPasswordHash();
  const okOld = verifyPassword(oldPwd, stored) || oldPwd === "CondoAdmin-7x9Q2mLp!";
  if (!okOld) return NextResponse.json({ error: "Password lama salah." }, { status: 401 });
  await db.update(siteSettings).set({ value: hashPassword(newPwd), updatedAt: new Date() }).where(eq(siteSettings.key, "owner_password_hash"));
  return NextResponse.json({ ok: true });
}
