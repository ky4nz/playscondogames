import { NextRequest, NextResponse } from "next/server";
import { ZipArchive } from "archiver";
import { createHash } from "crypto";
import { readdirSync, readFileSync, statSync } from "fs";
import { join } from "path";
import { PassThrough } from "stream";
import { db } from "@/db";
import { sessions } from "@/db/schema";
import { eq } from "drizzle-orm";
import {
  checkRateLimit,
  getBearerToken,
  getClientIp,
  hashIp,
} from "@/lib/auth";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

// HANYA OWNER. Admin/penyewa/publik SELALU ditolak.
// - Tanpa token / token tidak valid / kedaluwarsa -> 401 (minta login ulang).
// - Token valid tapi role=admin -> 404 samaran (endpoint seolah tidak ada, anti bocor).
// - Token TIDAK PERNAH diterima via query (?token=) agar tidak bocor di URL/log/history.

const MAX_FILES = 400;
const MAX_FILE_BYTES = 200_000;

const DENY_DIRS = new Set([
  "node_modules",
  ".next",
  ".git",
  ".vercel",
  ".turbo",
  "coverage",
  ".cache",
]);

const DENY_FILES = new Set([
  ".env",
  ".env.local",
  ".env.production",
  ".env.production.local",
  ".env.development.local",
  ".env.test.local",
  "id_rsa",
  "id_ed25519",
  ".pem",
]);

const ALLOW_ROOT_FILES = new Set([
  "package.json",
  "package-lock.json",
  "tsconfig.json",
  "next.config.ts",
  "postcss.config.mjs",
  "eslint.config.mjs",
  "drizzle.config.ts",
  "drizzle.config.json",
  "vercel.json",
  ".gitignore",
  ".env.example",
  "README.md",
  "DEPLOY.md",
  "next-env.d.ts",
]);

function isTextFile(rel: string): boolean {
  return /\.(ts|tsx|js|jsx|mjs|cjs|json|css|md|txt|example|gitignore|html|yml|yaml)$/i.test(rel);
}

function walk(dir: string, base: string, out: string[]) {
  let entries: string[] = [];
  try {
    entries = readdirSync(dir);
  } catch {
    return;
  }
  for (const e of entries) {
    if (out.length >= MAX_FILES) return;
    if (DENY_DIRS.has(e)) continue;
    if (e.endsWith(".log")) continue;
    const full = join(dir, e);
    let st;
    try {
      st = statSync(full);
    } catch {
      continue;
    }
    if (st.isDirectory()) {
      walk(full, base, out);
    } else if (st.isFile()) {
      if (st.size <= 0 || st.size > MAX_FILE_BYTES) continue;
      const rel = full.replace(base + "/", "").replace(/\\/g, "/");
      if (rel.startsWith(".git/") || rel.startsWith(".next/") || rel.startsWith("node_modules/")) continue;
      const baseName = rel.split("/").pop() || "";
      if (DENY_FILES.has(baseName) || DENY_FILES.has(rel)) continue;
      if (rel.startsWith("src/") || rel.startsWith("public/")) {
        out.push(full);
      }
    }
  }
}

// Hapus rahasia dari isi file teks sebelum masuk ZIP.
// PENTING: jangan merusak kode — kode hasil download harus langsung jalan.
// Yang di-redact hanya nilai env AKTIF + URL database di file config.
// Kode default (kyanzOWNER, fallback pepper) DIBIARKAN apa adanya agar web hasil
// extract tetap bisa login & jalan tanpa edit satu per satu.
function redact(rel: string, content: string): string {
  let out = content;
  const pepper = process.env.AUTH_PEPPER || "";
  const dbUrl = process.env.DATABASE_URL || "";
  // 1) Nilai env yang sedang aktif (paling sensitif) — hanya jika muncul di file
  if (pepper && pepper.length >= 8 && pepper !== "condo-pepper-kyanz-2026") {
    out = out.split(pepper).join("[REDACTED_AUTH_PEPPER]");
  }
  if (dbUrl && dbUrl.length >= 12 && !dbUrl.includes("127.0.0.1") && !dbUrl.includes("localhost")) {
    out = out.split(dbUrl).join("[REDACTED_DATABASE_URL]");
  }
  // 2) drizzle.config.json — ganti URL lokal dengan placeholder aman (tetap valid JSON)
  if (rel === "drizzle.config.json") {
    out = out.replace(
      /"url"\s*:\s*"[^"]*"/,
      '"url": "postgresql://USER:PASS@HOST:5432/DB"'
    );
  }
  return out;
}

async function requireOwnerStrict(req: NextRequest): Promise<
  | { ok: true; token: string }
  | { ok: false; status: 401 | 404 | 429; error: string; retryAfterSec?: number }
> {
  // Tolak token via URL (anti bocor lewat history/log/referer)
  try {
    const u = new URL(req.url);
    if (u.searchParams.get("token") || u.searchParams.get("t") || u.searchParams.get("auth")) {
      return { ok: false, status: 401, error: "Gunakan header Authorization. Token via URL ditolak." };
    }
  } catch {}

  const token = getBearerToken(req);
  if (!token) return { ok: false, status: 401, error: "Butuh login Owner." };

  // Rate limit ketat khusus download (anti brute-force / sedot berulang)
  const ip = getClientIp(req);
  const tokenHash = createHash("sha256").update(token).digest("hex").slice(0, 16);
  const rl = checkRateLimit(`dl:${tokenHash}:${hashIp(ip)}`, 5, 10 * 60_000);
  if (!rl.allowed) {
    return {
      ok: false,
      status: 429,
      error: `Terlalu sering download. Coba lagi dalam ${rl.retryAfterSec} detik.`,
      retryAfterSec: rl.retryAfterSec,
    };
  }

  const rows = await db.select().from(sessions).where(eq(sessions.token, token));
  if (rows.length === 0) return { ok: false, status: 401, error: "Sesi tidak valid. Login ulang sebagai Owner." };
  const s = rows[0];
  if (new Date(s.expiresAt).getTime() < Date.now()) {
    await db.delete(sessions).where(eq(sessions.token, token)).catch(() => {});
    return { ok: false, status: 401, error: "Sesi kedaluwarsa. Login ulang sebagai Owner." };
  }
  // KUNCI: role selain owner (termasuk admin valid) dianggap TIDAK ADA -> 404 samaran.
  if (s.role !== "owner") {
    return { ok: false, status: 404, error: "Not found." };
  }
  return { ok: true, token };
}

export async function GET(req: NextRequest) {
  const auth = await requireOwnerStrict(req);
  if (!auth.ok) {
    const headers: Record<string, string> = {
      "cache-control": "no-store",
      "X-Robots-Tag": "noindex, nofollow",
    };
    if (auth.status === 429 && auth.retryAfterSec) headers["retry-after"] = String(auth.retryAfterSec);
    return NextResponse.json({ error: auth.error }, { status: auth.status, headers });
  }

  const base = process.cwd();
  const files: string[] = [];
  walk(join(base, "src"), base, files);
  try {
    walk(join(base, "public"), base, files);
  } catch {}
  for (const f of [...ALLOW_ROOT_FILES]) {
    try {
      const full = join(base, f);
      const st = statSync(full);
      if (st.isFile() && st.size > 0 && st.size <= MAX_FILE_BYTES) files.push(full);
    } catch {}
  }
  const picked = files.slice(0, MAX_FILES);

  const date = new Date().toISOString().slice(0, 10);
  const zipName = `playscondogames-source-${date}.zip`;
  // Folder utama di dalam ZIP — setelah extract langsung jadi folder berisi banyak file terpisah.
  // Tidak perlu susun satu per satu: struktur src/, public/, config sudah rapi per file.
  const ROOT = "playscondogames";

  const archive = new ZipArchive({ zlib: { level: 9 } });
  const stream = new PassThrough();
  const chunks: Buffer[] = [];
  stream.on("data", (c: Buffer) => chunks.push(Buffer.isBuffer(c) ? c : Buffer.from(c)));
  const done = new Promise<Buffer>((resolve, reject) => {
    stream.on("end", () => resolve(Buffer.concat(chunks)));
    stream.on("error", reject);
    archive.on("error", reject);
  });
  archive.pipe(stream);

  const readmeOwner = [
    "playscondogames — Source Code (KHUSUS OWNER, RAHASIA)",
    "====================================================",
    `Diekspor: ${new Date().toISOString()}`,
    `Isi: ${picked.length} file TERPISAH di dalam folder ${ROOT}/`,
    `Struktur: ${ROOT}/src/... , ${ROOT}/public/... , ${ROOT}/package.json, config, README, DEPLOY`,
    "",
    "WAJIB EXTRACT DULU:",
    "1. Klik kanan file .zip ini → Extract All / Extract Here",
    "2. Hasilnya folder playscondogames/ berisi BANYAK file terpisah (bukan 1 file)",
    "3. Tidak perlu susun satu per satu — struktur folder sudah rapi",
    "4. Kalau 1 file bermasalah, cukup perbaiki file itu saja, lainnya tidak ikut rusak",
    "",
    "KEAMANAN:",
    "- File ini HANYA untuk Owner. JANGAN bagikan ke admin/penyewa/publik.",
    "- File .env TIDAK ikut (gunakan .env.example sebagai contoh).",
    "- Kode tetap utuh & langsung jalan (tidak ada yang dirusak).",
    "",
    "Cara pakai setelah extract:",
    "1. cd playscondogames",
    "2. npm install",
    "3. cp .env.example .env lalu isi DATABASE_URL + AUTH_PEPPER",
    "4. npx drizzle-kit push --config=drizzle.config.ts",
    "5. npm run build && npm run start",
    "",
    "Deploy Vercel: baca DEPLOY.md di dalam folder ini",
    "",
  ].join("\n");
  archive.append(readmeOwner, { name: `${ROOT}/README-OWNER.txt` });

  const caraExtract = [
    "WAJIB EXTRACT DULU — JANGAN dipakai langsung dari dalam ZIP",
    "===========================================================",
    "",
    "File yang kamu download adalah ZIP berisi FOLDER + BANYAK FILE TERPISAH.",
    "Kalau tidak di-extract, isinya tidak bisa dipakai / tidak bisa di-upload ke GitHub.",
    "",
    "Windows:",
    "  1. Klik kanan playscondogames-source-....zip → Extract All...",
    "  2. Pilih folder tujuan → Extract",
    "  3. Masuk ke folder hasil: playscondogames/",
    "",
    "Mac:",
    "  1. Double-click file .zip",
    "  2. Masuk ke folder hasil: playscondogames/",
    "",
    "HP Android:",
    "  1. Buka aplikasi Files / File Manager",
    "  2. Tap file .zip → Extract",
    "",
    "Setelah extract kamu dapat:",
    "  playscondogames/",
    "  ├── src/            (semua kode, terpisah per file)",
    "  ├── public/         (gambar/video)",
    "  ├── package.json, tsconfig.json, next.config.ts, ...",
    "  ├── README.md, DEPLOY.md, .env.example, vercel.json",
    "  └── README-OWNER.txt (file ini)",
    "",
    "Upload ke GitHub: upload ISI folder playscondogames/ (bukan file .zip-nya).",
    "",
  ].join("\n");
  archive.append(caraExtract, { name: `${ROOT}/CARA-EXTRACT-DULU.txt` });

  for (const full of picked) {
    const rel = full.replace(base + "/", "").replace(/\\/g, "/");
    try {
      // Setiap file masuk sebagai entry TERPISAH di dalam folder playscondogames/
      const zipPath = `${ROOT}/${rel}`;
      if (isTextFile(rel)) {
        const raw = readFileSync(full, "utf8");
        archive.append(redact(rel, raw).slice(0, 60_000), { name: zipPath });
      } else {
        archive.append(readFileSync(full), { name: zipPath });
      }
    } catch {}
  }
  await archive.finalize();
  const buf = await done;

  return new NextResponse(new Uint8Array(buf), {
    status: 200,
    headers: {
      "content-type": "application/zip",
      "content-disposition": `attachment; filename="${zipName}"`,
      "content-length": String(buf.length),
      "cache-control": "no-store, no-cache, must-revalidate",
      pragma: "no-cache",
      "X-Robots-Tag": "noindex, nofollow",
      "X-Content-Type-Options": "nosniff",
      "X-File-Count": String(picked.length + 2),
      "X-Zip-Root": ROOT,
    },
  });
}
