import { NextRequest, NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { sessions, tenants } from "@/db/schema";
import { generateStrongPassword, hashPassword, requireAuth } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest, { params }: { params: Promise<{ slug: string }> }) {
  const a = await requireAuth(req, "owner");
  if (!a.ok) return NextResponse.json({ error: (a as { error: string }).error }, { status: 401 });
  const { slug } = await params;
  const body = await req.json().catch(() => ({}));
  let password = String(body.password || "").trim();
  if (!password) password = generateStrongPassword(14);
  if (password.length < 8) return NextResponse.json({ error: "Password minimal 8 karakter." }, { status: 400 });

  const dup = await db.select().from(tenants).where(eq(tenants.passwordHash, hashPassword(password)));
  if (dup.length > 0 && dup[0].slug !== slug) {
    return NextResponse.json({ error: "Password sudah dipakai admin lain. Wajib unik." }, { status: 400 });
  }
  await db.update(tenants).set({ passwordHash: hashPassword(password), passwordPlain: password }).where(eq(tenants.slug, slug));
  // paksa logout sesi lama penyewa tsb
  await db.delete(sessions).where(and(eq(sessions.role, "admin"), eq(sessions.tenantSlug, slug))).catch(() => {});
  return NextResponse.json({ ok: true, password, slug });
}
