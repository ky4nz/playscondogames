import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { serverConfigs, sessions, tenants, visits } from "@/db/schema";
import { formatRemaining, requireAuth } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ slug: string }> }) {
  const a = await requireAuth(req, "owner");
  if (!a.ok) return NextResponse.json({ error: (a as { error: string }).error }, { status: 401 });
  const { slug } = await params;
  const rows = await db.select().from(tenants).where(eq(tenants.slug, slug));
  if (rows.length === 0) return NextResponse.json({ error: "Penyewa tidak ditemukan." }, { status: 404 });

  const body = await req.json().catch(() => ({}));
  const patch: Partial<typeof tenants.$inferInsert> = {};
  if (typeof body.label === "string" && body.label.trim()) patch.label = body.label.trim().slice(0, 60);
  if (typeof body.note === "string") patch.note = body.note.slice(0, 200);
  if (typeof body.isActive === "boolean") patch.isActive = body.isActive;
  if (body.expiresAt) {
    const d = new Date(body.expiresAt);
    if (!isNaN(d.getTime())) {
      patch.expiresAt = d;
      // Jika diperpanjang ke depan, aktifkan lagi (link tetap kosong jika sempat di-reset — penyewa wajib isi ulang)
      if (d.getTime() > Date.now()) patch.isActive = true;
    }
  }
  if (body.extendHours) {
    const h = Math.min(Math.max(Number(body.extendHours) || 0, 1), 24 * 365);
    const base = Math.max(new Date(rows[0].expiresAt).getTime(), Date.now());
    patch.expiresAt = new Date(base + h * 3600 * 1000);
    patch.isActive = true;
  }

  const updated = await db.update(tenants).set(patch).where(eq(tenants.slug, slug)).returning();
  const t = updated[0];
  return NextResponse.json({ ok: true, tenant: { ...t, remaining: formatRemaining(t.expiresAt) } });
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ slug: string }> }) {
  const a = await requireAuth(req, "owner");
  if (!a.ok) return NextResponse.json({ error: (a as { error: string }).error }, { status: 401 });
  const { slug } = await params;
  await db.delete(visits).where(eq(visits.tenantSlug, slug)).catch(() => {});
  await db.delete(serverConfigs).where(eq(serverConfigs.tenantSlug, slug)).catch(() => {});
  await db.delete(sessions).where(eq(sessions.tenantSlug, slug)).catch(() => {});
  await db.delete(tenants).where(eq(tenants.slug, slug));
  return NextResponse.json({ ok: true });
}
