import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { serverConfigs } from "@/db/schema";
import { requireAuth } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest, { params }: { params: Promise<{ slug: string }> }) {
  const a = await requireAuth(req, "owner");
  if (!a.ok) return NextResponse.json({ error: (a as { error: string }).error }, { status: 401 });
  const { slug } = await params;
  await db
    .update(serverConfigs)
    .set({ realUrl: "", decoy1: "", decoy2: "", online: 0, updatedAt: new Date() })
    .where(eq(serverConfigs.tenantSlug, slug));
  return NextResponse.json({ ok: true, message: `Link Server 1/2/3 milik ${slug} di-reset.` });
}
