import { NextRequest, NextResponse } from "next/server";
import { desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { tenants, visits } from "@/db/schema";
import {
  formatRemaining,
  generateSlug,
  generateStrongPassword,
  hashPassword,
  requireAuth,
  sweepExpiredTenants,
} from "@/lib/auth";
import { ensureTenantServers } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const a = await requireAuth(req, "owner");
  if (!a.ok) return NextResponse.json({ error: (a as { error: string }).error }, { status: 401 });
  await sweepExpiredTenants().catch(() => {});

  const rows = await db.select().from(tenants).orderBy(desc(tenants.createdAt));
  // hitung visit/join per tenant (cepat untuk skala sewa)
  const counts = await db
    .select({ tenantSlug: visits.tenantSlug, type: visits.type, c: sql<number>`count(*)` })
    .from(visits)
    .groupBy(visits.tenantSlug, visits.type);

  const map: Record<string, { visit: number; join: number }> = {};
  for (const c of counts) {
    if (!map[c.tenantSlug]) map[c.tenantSlug] = { visit: 0, join: 0 };
    if (c.type === "join") map[c.tenantSlug].join = Number(c.c);
    else map[c.tenantSlug].visit = Number(c.c);
  }

  const data = rows.map((t) => ({
    slug: t.slug,
    label: t.label,
    passwordPlain: t.passwordPlain,
    expiresAt: t.expiresAt,
    remaining: formatRemaining(t.expiresAt),
    isActive: t.isActive && new Date(t.expiresAt).getTime() > Date.now(),
    lastLoginAt: t.lastLoginAt,
    loginCount: t.loginCount,
    note: t.note,
    createdAt: t.createdAt,
    visits: map[t.slug]?.visit || 0,
    joins: map[t.slug]?.join || 0,
    publicPath: `/r/${t.slug}`,
    publicQuery: `/?r=${t.slug}`,
  }));
  return NextResponse.json({ ok: true, tenants: data });
}

export async function POST(req: NextRequest) {
  const a = await requireAuth(req, "owner");
  if (!a.ok) return NextResponse.json({ error: (a as { error: string }).error }, { status: 401 });

  const body = await req.json().catch(() => ({}));
  const label = String(body.label || "").trim().slice(0, 60) || "Penyewa Baru";
  const note = String(body.note || "").slice(0, 200);
  let password = String(body.password || "").trim();
  const durationHours = Number(body.durationHours || 0);
  const durationDays = Number(body.durationDays || 0);
  const customExpiresAt = body.expiresAt ? new Date(body.expiresAt) : null;

  let expiresAt: Date;
  if (customExpiresAt && !isNaN(customExpiresAt.getTime()) && customExpiresAt.getTime() > Date.now()) {
    expiresAt = customExpiresAt;
  } else {
    const hours = durationHours > 0 ? durationHours : durationDays > 0 ? durationDays * 24 : 7 * 24;
    const capped = Math.min(Math.max(hours, 1), 24 * 365);
    expiresAt = new Date(Date.now() + capped * 3600 * 1000);
  }

  // Password: auto-generate kuat jika kosong, wajib unik (1 password = 1 admin sendiri)
  if (!password) {
    password = generateStrongPassword(14);
  } else {
    if (password.length < 8) return NextResponse.json({ error: "Password minimal 8 karakter agar tidak mudah ditebak." }, { status: 400 });
    if (password.length > 64) return NextResponse.json({ error: "Password maksimal 64 karakter." }, { status: 400 });
  }
  const exists = await db.select().from(tenants).where(eq(tenants.passwordHash, hashPassword(password)));
  if (exists.length > 0) {
    return NextResponse.json({ error: "Password sudah dipakai admin lain. Wajib unik — generate yang baru." }, { status: 400 });
  }

  // Slug unik
  let slug = generateSlug();
  for (let i = 0; i < 5; i++) {
    const chk = await db.select().from(tenants).where(eq(tenants.slug, slug));
    if (chk.length === 0) break;
    slug = generateSlug();
  }

  const inserted = await db
    .insert(tenants)
    .values({
      slug,
      label,
      passwordHash: hashPassword(password),
      passwordPlain: password,
      expiresAt,
      isActive: true,
      note,
    })
    .returning();

  await ensureTenantServers(slug);

  const t = inserted[0];
  return NextResponse.json({
    ok: true,
    tenant: {
      slug: t.slug,
      label: t.label,
      expiresAt: t.expiresAt,
      remaining: formatRemaining(t.expiresAt),
      publicPath: `/r/${t.slug}`,
      publicQuery: `/?r=${t.slug}`,
    },
    // Password langsung aktif & dikenali server saat itu juga
    password,
  });
}
