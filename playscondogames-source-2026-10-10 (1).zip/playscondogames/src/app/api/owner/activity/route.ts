import { NextRequest, NextResponse } from "next/server";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { visits } from "@/db/schema";
import { requireAuth } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const a = await requireAuth(req, "owner");
  if (!a.ok) return NextResponse.json({ error: (a as { error: string }).error }, { status: 401 });
  const url = new URL(req.url);
  const limit = Math.min(Math.max(Number(url.searchParams.get("limit")) || 80, 1), 300);
  const rows = await db.select().from(visits).orderBy(desc(visits.createdAt)).limit(limit);
  return NextResponse.json({ ok: true, activity: rows });
}
