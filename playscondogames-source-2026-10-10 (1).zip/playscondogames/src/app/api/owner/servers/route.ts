import { NextRequest, NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { serverConfigs } from "@/db/schema";
import { normalizeUrl, requireAuth, suspiciousDomainWarning, validateServerLinks } from "@/lib/auth";
import { ensureDefaults } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const a = await requireAuth(req, "owner");
  if (!a.ok) return NextResponse.json({ error: (a as { error: string }).error }, { status: 401 });
  await ensureDefaults();
  const rows = await db.select().from(serverConfigs).where(eq(serverConfigs.tenantSlug, "owner"));
  const sorted = rows.sort((x, y) => x.slot - y.slot);
  return NextResponse.json({ ok: true, servers: sorted });
}

export async function PUT(req: NextRequest) {
  const a = await requireAuth(req, "owner");
  if (!a.ok) return NextResponse.json({ error: (a as { error: string }).error }, { status: 401 });
  const body = await req.json().catch(() => ({}));
  // Dukung simpan per-server (body.server) atau bulk (body.servers)
  const list = Array.isArray(body.servers)
    ? body.servers
    : body.server
      ? [body.server]
      : [];
  const warnings: string[] = [];
  const saved: number[] = [];
  const incomplete: string[] = [];

  // Ambil existing untuk preserve field non-link (online, banner, dll tidak di-reset)
  const existing = await db.select().from(serverConfigs).where(eq(serverConfigs.tenantSlug, "owner"));
  const bySlot = new Map(existing.map((r) => [r.slot, r]));

  for (const s of list) {
    const slot = Number(s.slot);
    if (![1, 2, 3].includes(slot)) continue;
    const prev = bySlot.get(slot);
    if (!prev) continue;

    // Normalisasi link (paste tanpa https:// tetap diterima)
    const raw1 = s.decoy1 !== undefined ? String(s.decoy1) : prev.decoy1;
    const raw2 = s.decoy2 !== undefined ? String(s.decoy2) : prev.decoy2;
    const raw3 = s.realUrl !== undefined ? String(s.realUrl) : prev.realUrl;
    const link1 = raw1.trim() ? normalizeUrl(raw1) : "";
    const link2 = raw2.trim() ? normalizeUrl(raw2) : "";
    const link3 = raw3.trim() ? normalizeUrl(raw3) : "";

    for (const [lbl, u] of [["Link 1", link1], ["Link 2", link2], ["Link 3", link3]] as const) {
      if (!u) continue;
      const w = suspiciousDomainWarning(u);
      if (w) warnings.push(`Server 0${slot} ${lbl}: ${w}`);
    }

    const title = s.title !== undefined ? String(s.title || `Server 0${slot}`).slice(0, 60) : prev.title;
    const isActive = s.isActive !== undefined ? !!s.isActive : prev.isActive;
    // Auto-map: jika dikirim (dari tombol Ambil Map), update banner/metadata. Jika tidak dikirim, preserve.
    const imageUrl = s.imageUrl !== undefined ? String(s.imageUrl || "").trim().slice(0, 1000) : prev.imageUrl;
    const gameBy = s.gameBy !== undefined ? String(s.gameBy || "").trim().slice(0, 80) : prev.gameBy;
    const gameDesc = s.gameDesc !== undefined ? String(s.gameDesc || "").trim().slice(0, 600) : prev.gameDesc;
    const maturity = s.maturity !== undefined ? String(s.maturity || "").trim().slice(0, 40) : prev.maturity;

    // Simpan SELALU (tidak pernah tolak bulk) — link tidak boleh hilang
    await db
      .update(serverConfigs)
      .set({
        title,
        realUrl: link3,
        decoy1: link1,
        decoy2: link2,
        online: prev.online,
        maxOnline: prev.maxOnline,
        imageUrl,
        gameBy,
        gameDesc,
        maturity,
        isActive,
        updatedAt: new Date(),
      })
      .where(and(eq(serverConfigs.tenantSlug, "owner"), eq(serverConfigs.slot, slot)));
    saved.push(slot);

    // Catat kelengkapan sebagai info (bukan error blokir)
    if (isActive) {
      const errs = validateServerLinks(slot, link1, link2, link3);
      if (errs.length > 0) incomplete.push(...errs);
    }
  }

  // Hitung dari DB terbaru — sistem 2 server (slot 1-2), total 6 link
  const fresh = await db.select().from(serverConfigs).where(eq(serverConfigs.tenantSlug, "owner"));
  let filled = 0;
  for (const r of fresh) {
    if (r.slot !== 1 && r.slot !== 2) continue;
    if ((r.decoy1 || "").trim()) filled += 1;
    if ((r.decoy2 || "").trim()) filled += 1;
    if ((r.realUrl || "").trim()) filled += 1;
  }
  return NextResponse.json({
    ok: true,
    warnings,
    saved,
    incomplete,
    filled,
    total: 6,
    servers: fresh.sort((x, y) => x.slot - y.slot),
  });
}
