import { NextRequest, NextResponse } from "next/server";
import { and, desc, eq, gte, sql } from "drizzle-orm";
import { db } from "@/db";
import { serverConfigs, tenants, visits } from "@/db/schema";
import { formatRemaining, requireAuth, sweepExpiredTenants } from "@/lib/auth";

export const dynamic = "force-dynamic";

function dayKey(d: Date): string {
  return d.toISOString().slice(0, 10);
}

export async function GET(req: NextRequest) {
  const a = await requireAuth(req, "owner");
  if (!a.ok) return NextResponse.json({ error: (a as { error: string }).error }, { status: 401 });
  await sweepExpiredTenants().catch(() => {});

  const allTenants = await db.select().from(tenants);
  const now = Date.now();
  const active = allTenants.filter((t) => t.isActive && new Date(t.expiresAt).getTime() > now);
  const expired = allTenants.filter((t) => !(t.isActive && new Date(t.expiresAt).getTime() > now));
  const totalLogins = allTenants.reduce((s, t) => s + (t.loginCount || 0), 0);

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const todayRows = await db.select().from(visits).where(gte(visits.createdAt, today));
  const visitsToday = todayRows.filter((r) => r.type === "visit").length;
  const joinsToday = todayRows.filter((r) => r.type === "join").length;

  // 7 hari terakhir
  const since = new Date();
  since.setDate(since.getDate() - 6);
  since.setHours(0, 0, 0, 0);
  const weekRows = await db.select().from(visits).where(gte(visits.createdAt, since));
  const byDay: Record<string, { visit: number; join: number }> = {};
  for (let i = 0; i < 7; i++) {
    const d = new Date(since);
    d.setDate(since.getDate() + i);
    byDay[dayKey(d)] = { visit: 0, join: 0 };
  }
  for (const r of weekRows) {
    const k = dayKey(new Date(r.createdAt));
    if (!byDay[k]) byDay[k] = { visit: 0, join: 0 };
    if (r.type === "join") byDay[k].join += 1;
    else byDay[k].visit += 1;
  }
  const week = Object.entries(byDay).map(([day, v]) => ({ day, ...v }));

  // Server paling rame (join terbanyak 7 hari, fallback semua)
  const joinGroups = await db
    .select({ tenantSlug: visits.tenantSlug, serverSlot: visits.serverSlot, c: sql<number>`count(*)` })
    .from(visits)
    .where(and(gte(visits.createdAt, since), eq(visits.type, "join")))
    .groupBy(visits.tenantSlug, visits.serverSlot)
    .orderBy(desc(sql`count(*)`))
    .limit(5);

  let mostCrowded: { tenantSlug: string; slot: number; title: string; joins: number; label: string } | null = null;
  if (joinGroups.length > 0) {
    const g = joinGroups[0];
    const cfg = await db.select().from(serverConfigs).where(and(eq(serverConfigs.tenantSlug, g.tenantSlug), eq(serverConfigs.slot, g.serverSlot)));
    let label = g.tenantSlug === "owner" ? "Owner" : g.tenantSlug;
    if (g.tenantSlug !== "owner") {
      const t = allTenants.find((x) => x.slug === g.tenantSlug);
      if (t) label = t.label;
    }
    mostCrowded = {
      tenantSlug: g.tenantSlug,
      slot: g.serverSlot,
      title: cfg[0]?.title || `Server 0${g.serverSlot}`,
      joins: Number(g.c),
      label,
    };
  }

  const expiringSoon = active
    .map((t) => ({ slug: t.slug, label: t.label, expiresAt: t.expiresAt, remaining: formatRemaining(t.expiresAt), ms: new Date(t.expiresAt).getTime() - now }))
    .sort((a, b) => a.ms - b.ms)
    .slice(0, 5);

  return NextResponse.json({
    ok: true,
    totalAdmins: allTenants.length,
    activeAdmins: active.length,
    expiredAdmins: expired.length,
    totalLogins,
    visitsToday,
    joinsToday,
    week,
    mostCrowded,
    expiringSoon,
  });
}
