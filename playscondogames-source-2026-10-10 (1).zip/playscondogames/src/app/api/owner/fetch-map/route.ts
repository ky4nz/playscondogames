import { NextRequest, NextResponse } from "next/server";
import { requireAuth } from "@/lib/auth";
import { fetchMapInfo } from "@/lib/roblox";

export const dynamic = "force-dynamic";

// Ambil info map Roblox apa pun dari Link 1 — nama, creator, icon otomatis.
export async function POST(req: NextRequest) {
  const a = await requireAuth(req, "owner");
  if (!a.ok) return NextResponse.json({ error: (a as { error: string }).error }, { status: 401 });
  const body = await req.json().catch(() => ({}));
  const url = String(body.url || "").trim();
  if (!url) return NextResponse.json({ error: "URL kosong." }, { status: 400 });
  const info = await fetchMapInfo(url);
  if (!info.placeId) return NextResponse.json({ error: "Link bukan URL game Roblox (/games/PLACEID/...).", info }, { status: 400 });
  return NextResponse.json({ ok: true, info });
}
