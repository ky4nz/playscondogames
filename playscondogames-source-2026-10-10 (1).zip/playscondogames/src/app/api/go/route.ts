import { NextRequest, NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { serverConfigs, tenants } from "@/db/schema";
import { verifyFrameToken } from "@/lib/frameToken";

export const dynamic = "force-dynamic";

// Frame gateway: iframe di dalam web memuat /api/go?...&frame=1 lalu server redirect (302) ke Link 3.
// Link 3 mentah TIDAK PERNAH tampil di HTML/JS/devtools Elements — hanya /api/go yang terlihat.
// Navigasi langsung (buka /api/go di address bar) DITOLAK agar tidak pindah web/tab baru.
function stayInsideHtml(tenant: string) {
  const back = tenant && tenant !== "owner" ? `/r/${encodeURIComponent(tenant)}` : "/";
  return `<!DOCTYPE html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Tetap di Dalam Web — Condo Games</title>
<style>body{background:#0b0914;color:#f2f4fc;font-family:system-ui,sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;padding:20px} .c{max-width:440px;background:#13111f;border:1px solid rgba(168,85,247,.3);border-radius:18px;padding:28px;text-align:center} a{display:inline-block;margin-top:16px;background:linear-gradient(90deg,#8b5cf6,#ec4899);color:#fff;text-decoration:none;font-weight:700;padding:12px 22px;border-radius:12px}</style></head>
<body><div class="c"><div style="font-size:40px">💎</div><h2>Tetap di Dalam Web</h2><p style="color:#9aa9c7;font-size:14px">Link iframe hanya boleh dibuka di dalam web ini.<br>Klik JOIN dari daftar server — tidak pindah tab.</p><a href="${back}">← Kembali ke Server</a></div></body></html>`;
}

export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const tenant = (url.searchParams.get("tenant") || "owner").slice(0, 64);
  const slot = Number(url.searchParams.get("server") || 0);
  const frame = url.searchParams.get("frame") || "";
  const token = url.searchParams.get("t") || "";
  const dest = (req.headers.get("sec-fetch-dest") || "").toLowerCase();

  // Hanya iframe yang boleh: wajib frame=1 dan BUKAN navigasi dokumen langsung
  if (frame !== "1" || dest === "document") {
    const wantsJson = (req.headers.get("accept") || "").includes("application/json");
    if (wantsJson) {
      return NextResponse.json(
        { ok: false, stayInside: true, error: "Endpoint iframe saja. JOIN dari dalam web, tidak pindah tab." },
        { status: 410 }
      );
    }
    return new NextResponse(stayInsideHtml(tenant), {
      status: 200,
      headers: { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" },
    });
  }

  if (![1, 2, 3].includes(slot)) {
    return new NextResponse("Server tidak valid.", { status: 400 });
  }

  // Token sekali pakai wajib valid — cegah share/simpan/curl ulang URL iframe
  if (!verifyFrameToken(tenant, slot, token)) {
    return new NextResponse(stayInsideHtml(tenant), {
      status: 410,
      headers: { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" },
    });
  }
  if (tenant !== "owner") {
    const t = await db.select().from(tenants).where(eq(tenants.slug, tenant));
    if (t.length === 0) return new NextResponse("Link penyewa tidak valid.", { status: 404 });
    if (!t[0].isActive || new Date(t[0].expiresAt).getTime() < Date.now()) {
      return new NextResponse("Masa sewa habis.", { status: 410 });
    }
  }
  const rows = await db
    .select()
    .from(serverConfigs)
    .where(and(eq(serverConfigs.tenantSlug, tenant), eq(serverConfigs.slot, slot)));
  if (rows.length === 0 || !rows[0].isActive || !rows[0].realUrl) {
    return new NextResponse("Server belum dikonfigurasi.", { status: 404 });
  }
  let target = rows[0].realUrl.trim();
  if (!/^https?:\/\//i.test(target)) target = "https://" + target;
  try {
    new URL(target);
  } catch {
    return new NextResponse("URL server tidak valid.", { status: 400 });
  }

  // 302 di dalam iframe — halaman utama TIDAK pindah, tetap di modal dalam web
  const res = NextResponse.redirect(target, 302);
  res.headers.set("Referrer-Policy", "no-referrer");
  res.headers.set("X-Robots-Tag", "noindex, nofollow");
  res.headers.set("Cache-Control", "no-store");
  return res;
}
