import PublicHome from "@/components/PublicHome";

export const dynamic = "force-dynamic";

export default function HomePage() {
  return <PublicHome />;
}
