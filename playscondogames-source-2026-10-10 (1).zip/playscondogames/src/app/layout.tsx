import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

const siteUrl =
  process.env.VERCEL_PROJECT_PRODUCTION_URL
    ? `https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}`
    : process.env.VERCEL_URL
      ? `https://${process.env.VERCEL_URL}`
      : "https://playscondogames.vercel.app";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: "playscondogames · Private Servers",
  description:
    "playscondogames — pilih private server Roblox favoritmu dan join tanpa keluar dari web.",
  robots: { index: true, follow: true },
  openGraph: {
    title: "playscondogames · Private Servers",
    description: "Pilih private server Roblox favoritmu dan join tanpa keluar dari web.",
    type: "website",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="id">
      <head>
        <link
          href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,400;14..32,500;14..32,600;14..32,700;14..32,800;14..32,900&display=swap"
          rel="stylesheet"
        />
        <link
          rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
        />
      </head>
      <body className="antialiased">{children}</body>
    </html>
  );
}
