"use client";

import { useCallback, useEffect, useState } from "react";
import AntiInspect from "@/components/AntiInspect";
import MyWebsiteCard from "@/components/MyWebsiteCard";
import WebsiteBrandingCard from "@/components/WebsiteBrandingCard";

type TenantRow = {
  slug: string;
  label: string;
  passwordPlain: string;
  expiresAt: string;
  remaining: string;
  isActive: boolean;
  lastLoginAt: string | null;
  loginCount: number;
  note: string;
  createdAt: string;
  visits: number;
  joins: number;
  publicPath: string;
  publicQuery: string;
};

type ServerRow = {
  slot: number;
  title: string;
  realUrl: string;
  decoy1: string;
  decoy2: string;
  online: number;
  maxOnline: number;
  imageUrl: string;
  gameBy: string;
  gameDesc: string;
  maturity: string;
  isActive: boolean;
};

function getOwnerToken(): string {
  if (typeof window === "undefined") return "";
  try {
    return sessionStorage.getItem("cg_owner_token") || localStorage.getItem("cg_owner_token") || "";
  } catch {
    return "";
  }
}

function authHeaders(): Record<string, string> {
  return { "content-type": "application/json", authorization: `Bearer ${getOwnerToken()}` };
}

function clearOwnerToken() {
  try {
    sessionStorage.removeItem("cg_owner_token");
  } catch {}
  try {
    localStorage.removeItem("cg_owner_token");
  } catch {}
}

export default function OwnerPage() {
  const [ready, setReady] = useState(false);
  const [tab, setTab] = useState<"overview" | "tenants" | "servers" | "stats" | "activity" | "download" | "settings">("overview");
  const [stats, setStats] = useState<{
    totalAdmins: number; activeAdmins: number; expiredAdmins: number; totalLogins: number;
    visitsToday: number; joinsToday: number;
    week: { day: string; visit: number; join: number }[];
    mostCrowded: { tenantSlug: string; slot: number; title: string; joins: number; label: string } | null;
    expiringSoon: { slug: string; label: string; expiresAt: string; remaining: string }[];
  } | null>(null);
  const [tenants, setTenants] = useState<TenantRow[]>([]);
  const [servers, setServers] = useState<ServerRow[]>([]);
  const [activity, setActivity] = useState<{ id: string; tenantSlug: string; serverSlot: number; type: string; createdAt: string; ipHash: string }[]>([]);
  const [msg, setMsg] = useState("");
  const [err, setErr] = useState("");

  // generate form
  const [gLabel, setGLabel] = useState("");
  const [gDays, setGDays] = useState("7");
  const [gCustomHours, setGCustomHours] = useState("");
  const [gNote, setGNote] = useState("");
  const [gResult, setGResult] = useState<{ password: string; slug: string; publicPath: string } | null>(null);
  const [gLoading, setGLoading] = useState(false);
  // Password disembunyikan default agar tidak bocor di layar — owner klik Lihat untuk tampilkan
  const [revealed, setRevealed] = useState<Record<string, boolean>>({});
  const [showGResult, setShowGResult] = useState(false);

  function maskPwd(p: string): string {
    if (!p) return "••••••••";
    return "•".repeat(Math.min(Math.max(p.length, 8), 14));
  }

  function toggleReveal(slug: string) {
    setRevealed((prev) => ({ ...prev, [slug]: !prev[slug] }));
  }

  const [srvWarn, setSrvWarn] = useState<string[]>([]);
  const [oldPwd, setOldPwd] = useState("");
  const [newPwd, setNewPwd] = useState("");
  const [dlLoading, setDlLoading] = useState(false);
  const [dlErr, setDlErr] = useState("");
  const [dlOk, setDlOk] = useState("");

  async function handleOwnerDownload() {
    const t = getOwnerToken();
    if (!t) {
      setDlErr("Sesi Owner tidak ditemukan. Login ulang sebagai Owner.");
      return;
    }
    if (!window.confirm("Download source code playscondogames (.zip)?\n\nIsi: FOLDER playscondogames/ berisi BANYAK file terpisah (src/, public/, config).\nWAJIB di-EXTRACT dulu setelah download.\n\nFile ini RAHASIA khusus Owner. Jangan bagikan ke admin/penyewa/publik.")) return;
    setDlLoading(true);
    setDlErr("");
    setDlOk("");
    try {
      // Token HANYA via header (tidak pernah di URL) — tidak bocor ke history/log.
      const res = await fetch("/api/owner/download-source", {
        headers: { authorization: `Bearer ${t}` },
        cache: "no-store",
      });
      if (res.status === 401) {
        setDlErr("Sesi Owner kedaluwarsa. Login ulang, lalu coba lagi.");
        return;
      }
      if (res.status === 404) {
        setDlErr("Endpoint tidak ditemukan / akses ditolak.");
        return;
      }
      if (res.status === 429) {
        const j = await res.json().catch(() => ({} as { error?: string }));
        setDlErr(j.error || "Terlalu sering download. Tunggu sebentar.");
        return;
      }
      if (!res.ok) {
        const j = await res.json().catch(() => ({} as { error?: string }));
        setDlErr(j.error || "Gagal download.");
        return;
      }
      const blob = await res.blob();
      if (!blob || blob.size < 1000) {
        setDlErr("File ZIP rusak/kosong. Coba download ulang.");
        return;
      }
      // Pakai nama file dari server kalau ada
      let fileName = `playscondogames-source-${new Date().toISOString().slice(0, 10)}.zip`;
      try {
        const cd = res.headers.get("content-disposition") || "";
        const m = cd.match(/filename="([^"]+)"/);
        if (m && m[1]) fileName = m[1];
      } catch {}
      const fileCount = res.headers.get("X-File-Count") || "";
      const aEl = document.createElement("a");
      const objUrl = URL.createObjectURL(blob);
      aEl.href = objUrl;
      aEl.download = fileName;
      document.body.appendChild(aEl);
      aEl.click();
      aEl.remove();
      window.setTimeout(() => URL.revokeObjectURL(objUrl), 5000);
      setDlOk(`Berhasil download ${fileName}${fileCount ? ` (${fileCount} file)` : ""}. WAJIB EXTRACT dulu → dapat folder playscondogames/ berisi banyak file terpisah.`);
    } catch {
      setDlErr("Gagal download. Periksa koneksi lalu coba lagi.");
    } finally {
      setDlLoading(false);
    }
  }
  // Anti-hilang: lacak form yang belum tersimpan + status per-server
  const [dirtySlots, setDirtySlots] = useState<Record<number, boolean>>({});
  const [savingSlot, setSavingSlot] = useState<number | null>(null);
  const [savedAt, setSavedAt] = useState<Record<number, string>>({});
  const [srvErr, setSrvErr] = useState("");
  // Server join cuma 2 — Server 03 disembunyikan kecuali sudah ada isi/aktif
  const [showThird, setShowThird] = useState(false);

  function markDirty(slot: number) {
    setDirtySlots((prev) => ({ ...prev, [slot]: true }));
  }

  const visibleServers = showThird ? servers : servers.filter((s) => s.slot !== 3);
  const totalLinks = visibleServers.length * 3;

  function slotHasData(s: { decoy1: string; decoy2: string; realUrl: string; isActive: boolean }): boolean {
    // Hanya link yang menentukan — isActive TIDAK ikut agar Server 03 kosong tidak memaksa tampil
    return !!(s.decoy1 || "").trim() || !!(s.decoy2 || "").trim() || !!(s.realUrl || "").trim();
  }

  const loadAll = useCallback(async (opts?: { skipServers?: boolean }) => {
    setErr("");
    try {
      const me = await fetch("/api/auth/me", { headers: authHeaders() });
      if (!me.ok) {
        window.location.href = "/";
        return;
      }
      const mj = await me.json();
      if (mj.role !== "owner") {
        window.location.href = "/";
        return;
      }
      setReady(true);
      const [s, t, sv, ac] = await Promise.all([
        fetch("/api/owner/stats", { headers: authHeaders() }).then((r) => r.json()),
        fetch("/api/owner/tenants", { headers: authHeaders() }).then((r) => r.json()),
        opts?.skipServers ? Promise.resolve(null) : fetch("/api/owner/servers", { headers: authHeaders() }).then((r) => r.json()),
        fetch("/api/owner/activity?limit=80", { headers: authHeaders() }).then((r) => r.json()),
      ]);
      if (s.ok) setStats(s);
      if (t.ok) setTenants(t.tenants);
      // Jangan timpa form yang sedang diketik (dirty) agar link tidak hilang saat auto-refresh
      if (sv && sv.ok) {
        const list = sv.servers || [];
        const third = list.find((x: { slot: number }) => x.slot === 3);
        if (third && slotHasData(third)) setShowThird(true);
        setDirtySlots((dirty) => {
          const hasDirty = Object.values(dirty).some(Boolean);
          if (!hasDirty) setServers(list);
          return dirty;
        });
      }
      if (ac.ok) setActivity(ac.activity);
    } catch {
      setErr("Gagal memuat data owner.");
    }
  }, []);

  useEffect(() => {
    loadAll();
    // Auto-refresh hanya stats/tenants/activity — form server TIDAK di-refresh otomatis agar tidak ke-reset
    const iv = window.setInterval(() => loadAll({ skipServers: true }), 30000);
    return () => window.clearInterval(iv);
  }, [loadAll]);

  async function handleGenerate(e: React.FormEvent) {
    e.preventDefault();
    setGLoading(true);
    setMsg("");
    setErr("");
    setGResult(null);
    try {
      let durationDays = 0;
      let durationHours = 0;
      if (gDays === "custom") durationHours = Math.max(Number(gCustomHours) || 0, 1);
      else durationDays = Number(gDays);
      const res = await fetch("/api/owner/tenants", {
        method: "POST",
        headers: authHeaders(),
        body: JSON.stringify({ label: gLabel || "Penyewa Baru", durationDays, durationHours, note: gNote }),
      });
      const j = await res.json();
      if (!res.ok) {
        setErr(j.error || "Gagal generate password.");
        return;
      }
      setGResult({ password: j.password, slug: j.tenant.slug, publicPath: j.tenant.publicPath });
      setShowGResult(false);
      setGLabel("");
      setGNote("");
      setMsg(`Password baru langsung AKTIF untuk "${j.tenant.slug}" — klik Lihat lalu Salin untuk kirim ke penyewa.`);
      loadAll();
    } catch {
      setErr("Jaringan bermasalah.");
    } finally {
      setGLoading(false);
    }
  }

  async function act(slug: string, kind: "extend7" | "extend30" | "reset" | "regen" | "delete" | "toggle") {
    if (kind === "delete" && !confirm(`Hapus permanen ${slug}? Link + statistik ikut terhapus.`)) return;
    if (kind === "reset" && !confirm(`Reset Link Server 1/2/3 milik ${slug}?`)) return;
    setMsg("");
    setErr("");
    try {
      if (kind === "extend7" || kind === "extend30") {
        const r = await fetch(`/api/owner/tenants/${slug}`, { method: "PATCH", headers: authHeaders(), body: JSON.stringify({ extendHours: kind === "extend7" ? 168 : 720 }) });
        const j = await r.json();
        if (!r.ok) setErr(j.error);
        else setMsg(`${slug} diperpanjang → ${j.tenant.remaining}`);
      } else if (kind === "reset") {
        const r = await fetch(`/api/owner/tenants/${slug}/reset-links`, { method: "POST", headers: authHeaders() });
        const j = await r.json();
        if (!r.ok) setErr(j.error);
        else setMsg(j.message);
      } else if (kind === "regen") {
        if (!confirm(`Buat password baru untuk ${slug}? Password lama langsung mati & penyewa otomatis logout.`)) return;
        const r = await fetch(`/api/owner/tenants/${slug}/regenerate-password`, { method: "POST", headers: authHeaders(), body: JSON.stringify({}) });
        const j = await r.json();
        if (!r.ok) setErr(j.error);
        else {
          // Password TIDAK ditulis di banner agar tidak bocor di layar — owner klik Lihat di tabel + Salin
          setRevealed((prev) => ({ ...prev, [slug]: false }));
          setMsg(`Password baru untuk ${slug} sudah aktif. Klik Lihat di tabel lalu Salin untuk kirim ke penyewa.`);
          try {
            await navigator.clipboard.writeText(j.password);
            setMsg(`Password baru untuk ${slug} sudah aktif & otomatis tersalin. Tempel & kirim ke penyewa.`);
          } catch {}
        }
      } else if (kind === "delete") {
        const r = await fetch(`/api/owner/tenants/${slug}`, { method: "DELETE", headers: authHeaders() });
        if (!r.ok) setErr("Gagal hapus.");
        else setMsg(`${slug} dihapus.`);
      } else if (kind === "toggle") {
        const row = tenants.find((t) => t.slug === slug);
        const r = await fetch(`/api/owner/tenants/${slug}`, { method: "PATCH", headers: authHeaders(), body: JSON.stringify({ isActive: !(row?.isActive) }) });
        const j = await r.json();
        if (!r.ok) setErr(j.error);
        else setMsg(`${slug} → ${j.tenant.isActive ? "AKTIF" : "NONAKTIF"}`);
      }
      loadAll();
    } catch {
      setErr("Aksi gagal.");
    }
  }

  const [fetchingMap, setFetchingMap] = useState<number | null>(null);

  async function autoFillMap(slot: number) {
    const row = servers.find((p) => p.slot === slot);
    if (!row) return;
    const link1 = (row.decoy1 || "").trim();
    if (!link1) {
      setSrvErr(`Isi Link 1 dulu untuk Server 0${slot}, lalu klik Ambil Map Otomatis.`);
      return;
    }
    setFetchingMap(slot);
    setSrvErr("");
    try {
      const r = await fetch("/api/owner/fetch-map", {
        method: "POST",
        headers: authHeaders(),
        body: JSON.stringify({ url: link1 }),
      });
      const j = await r.json();
      if (!r.ok) {
        setSrvErr(j.error || "Gagal ambil info map.");
        return;
      }
      const info = j.info || {};
      setServers((prev) =>
        prev.map((p) =>
          p.slot === slot
            ? {
                ...p,
                title: info.name ? `${info.name}`.slice(0, 60) : p.title,
                imageUrl: info.iconUrl || p.imageUrl,
                gameBy: info.creator || p.gameBy,
                gameDesc: info.description || p.gameDesc,
              }
            : p
        )
      );
      markDirty(slot);
      setMsg(
        info.name
          ? `Map terdeteksi: ${info.name}${info.creator ? ` by ${info.creator}` : ""} — judul + banner terisi otomatis. Klik Simpan.`
          : "Link terbaca. Klik Simpan."
      );
    } catch {
      setSrvErr("Gagal ambil info map.");
    } finally {
      setFetchingMap(null);
    }
  }

  // Simpan per-server agar tidak gagal gara-gara server lain belum lengkap + link tidak hilang
  async function saveOneServer(slot: number) {
    const row = servers.find((p) => p.slot === slot);
    if (!row) return;
    setSavingSlot(slot);
    setSrvErr("");
    setSrvWarn([]);
    try {
      const r = await fetch("/api/owner/servers", {
        method: "PUT",
        headers: authHeaders(),
        body: JSON.stringify({
          server: { slot: row.slot, title: row.title, decoy1: row.decoy1, decoy2: row.decoy2, realUrl: row.realUrl, isActive: row.isActive, imageUrl: row.imageUrl, gameBy: row.gameBy, gameDesc: row.gameDesc, maturity: row.maturity },
        }),
      });
      const j = await r.json();
      if (!r.ok) {
        setSrvErr(j.error || `Gagal simpan Server 0${slot}.`);
        return;
      }
      if (j.warnings?.length) setSrvWarn(j.warnings);
      if (j.servers) {
        setServers(j.servers);
        const third = j.servers.find((x: { slot: number }) => x.slot === 3);
        if (third && slotHasData(third)) setShowThird(true);
      }
      setDirtySlots((prev) => ({ ...prev, [slot]: false }));
      const now = new Date().toLocaleTimeString("id-ID");
      setSavedAt((prev) => ({ ...prev, [slot]: now }));
      setMsg(`Server 0${slot} tersimpan permanen (${now}). Link tidak akan hilang saat refresh.`);
      if (j.incomplete?.length) {
        setSrvErr(`Catatan: ${j.incomplete.join(" ")} (tetap tersimpan, lengkapi agar JOIN jalan).`);
      }
      loadAll({ skipServers: true });
    } catch {
      setSrvErr(`Gagal simpan Server 0${slot}. Cek koneksi.`);
    } finally {
      setSavingSlot(null);
    }
  }

  async function saveServers() {
    setMsg("");
    setErr("");
    setSrvErr("");
    setSrvWarn([]);
    try {
      // Hanya kirim server yang tampil (2 server) agar Server 03 tersembunyi tidak ikut ke-reset
      const toSend = visibleServers.map((row) => ({ slot: row.slot, title: row.title, decoy1: row.decoy1, decoy2: row.decoy2, realUrl: row.realUrl, isActive: row.isActive, imageUrl: row.imageUrl, gameBy: row.gameBy, gameDesc: row.gameDesc, maturity: row.maturity }));
      const r = await fetch("/api/owner/servers", {
        method: "PUT",
        headers: authHeaders(),
        body: JSON.stringify({ servers: toSend }),
      });
      const j = await r.json();
      if (!r.ok) {
        setSrvErr(j.error || "Gagal simpan.");
        return;
      }
      if (j.warnings?.length) setSrvWarn(j.warnings);
      if (j.servers) setServers(j.servers);
      setDirtySlots({});
      const now = new Date().toLocaleTimeString("id-ID");
      const stamp: Record<number, string> = {};
      for (const s of visibleServers) stamp[s.slot] = now;
      setSavedAt((prev) => ({ ...prev, ...stamp }));
      const f = countFilled();
      setMsg(`Semua tersimpan permanen (${now}). Total ${f}/${totalLinks} link. Tidak akan hilang saat refresh.`);
      if (j.incomplete?.length) setSrvErr(`Catatan: ${j.incomplete.join(" ")} (tetap tersimpan).`);
      loadAll({ skipServers: true });
    } catch {
      setSrvErr("Gagal simpan.");
    }
  }

  function countFilled(): number {
    let n = 0;
    for (const s of visibleServers) {
      if ((s.decoy1 || "").trim()) n += 1;
      if ((s.decoy2 || "").trim()) n += 1;
      if ((s.realUrl || "").trim()) n += 1;
    }
    return n;
  }

  async function changePwd(e: React.FormEvent) {
    e.preventDefault();
    setMsg("");
    setErr("");
    const r = await fetch("/api/owner/change-password", { method: "POST", headers: authHeaders(), body: JSON.stringify({ oldPassword: oldPwd, newPassword: newPwd }) });
    const j = await r.json();
    if (!r.ok) {
      setErr(j.error);
      return;
    }
    setOldPwd("");
    setNewPwd("");
    setMsg("Password Owner berhasil diganti.");
  }

  function logout() {
    fetch("/api/auth/logout", { method: "POST", headers: authHeaders() }).finally(() => {
      clearOwnerToken();
      window.location.href = "/";
    });
  }

  function copy(text: string, label = "Tersalin!") {
    try {
      navigator.clipboard.writeText(text).then(() => setMsg(label));
    } catch {
      prompt("Salin manual:", text);
    }
  }

  if (!ready) {
    return (
      <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", color: "#8a99b9" }}>
        Memeriksa sesi Owner...
      </div>
    );
  }

  const maxBar = Math.max(1, ...(stats?.week.map((w) => Math.max(w.visit, w.join)) || [1]));

  return (
    <AntiInspect label="OWNER PANEL TERPROTEKSI">
      <div style={{ minHeight: "100vh", background: "#0b0914" }}>
        <header className="navbar">
          <div className="nav-brand">
            <div className="brand-icon"><i className="fa-solid fa-gem" /></div>
            <span>OWNER <span className="grad">PANEL</span></span>
            <span className="badge badge-amber" style={{ marginLeft: 8 }}><i className="fa-solid fa-crown" /> OWNER</span>
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <button className="btn-ghost" onClick={() => (window.location.href = "/")}>Lihat Web</button>
            <button className="btn-danger" onClick={logout}>Keluar</button>
          </div>
        </header>

        {(msg || err) && (
          <div style={{ maxWidth: 1200, margin: "14px auto 0", padding: "0 16px" }}>
            {msg && <div style={{ background: "rgba(16,185,129,0.1)", border: "1px solid rgba(16,185,129,0.3)", color: "#6ee7b7", fontSize: 13, padding: "10px 14px", borderRadius: 12 }}>{msg}</div>}
            {err && <div style={{ background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.3)", color: "#fca5a5", fontSize: 13, padding: "10px 14px", borderRadius: 12, marginTop: msg ? 8 : 0 }}>{err}</div>}
          </div>
        )}

        <div style={{ maxWidth: 1200, margin: "0 auto", padding: 16, display: "grid", gridTemplateColumns: "230px 1fr", gap: 16 }}>
          <aside className="panel" style={{ alignSelf: "start", position: "sticky", top: 76 }}>
            <div className="panel-head"><i className="fa-solid fa-layer-group" style={{ color: "#a855f7" }} /><div className="panel-title">Navigasi Owner</div></div>
            <div className="panel-body" style={{ display: "flex", flexDirection: "column", gap: 6 }}>
              {[
                { k: "overview", icon: "fa-gauge-high", label: "① Overview Dashboard" },
                { k: "tenants", icon: "fa-users", label: "② Penyewa & Password" },
                { k: "servers", icon: "fa-server", label: "③ Link Server Owner" },
                { k: "stats", icon: "fa-chart-column", label: "④ Statistik Harian" },
                { k: "activity", icon: "fa-clock-rotate-left", label: "⑤ Log Aktivitas" },
                { k: "download", icon: "fa-download", label: "⑥ Download Source" },
                { k: "settings", icon: "fa-gear", label: "⑦ Pengaturan" },
              ].map((m) => (
                <button key={m.k} className={`side-link ${tab === m.k ? "active" : ""}`} onClick={() => setTab(m.k as typeof tab)}>
                  <i className={`fa-solid ${m.icon}`} /> {m.label}
                </button>
              ))}
            </div>
          </aside>

          <main style={{ display: "flex", flexDirection: "column", gap: 16, minWidth: 0 }}>
            {tab === "overview" && (
              <>
                <div className="panel">
                  <div className="panel-head">
                    <i className="fa-solid fa-gauge-high" style={{ color: "#a855f7" }} />
                    <div><div className="panel-title">Panel ① — Overview Dashboard Owner</div><div className="panel-sub">Ringkasan sewa, login, visit & server paling rame.</div></div>
                  </div>
                  <div className="panel-body">
                    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(150px,1fr))", gap: 12 }}>
                      {[
                        { l: "Total Admin/Penyewa", v: stats?.totalAdmins ?? 0, icon: "fa-users" },
                        { l: "Aktif", v: stats?.activeAdmins ?? 0, icon: "fa-circle-check" },
                        { l: "Kedaluwarsa", v: stats?.expiredAdmins ?? 0, icon: "fa-circle-exclamation" },
                        { l: "Total Login Admin", v: stats?.totalLogins ?? 0, icon: "fa-right-to-bracket" },
                        { l: "Visit Hari Ini", v: stats?.visitsToday ?? 0, icon: "fa-eye" },
                        { l: "Join Hari Ini", v: stats?.joinsToday ?? 0, icon: "fa-play" },
                      ].map((c) => (
                        <div key={c.l} className="stat-card">
                          <div style={{ fontSize: 11, color: "#8a99b9", fontWeight: 700 }}><i className={`fa-solid ${c.icon}`} style={{ marginRight: 6 }} />{c.l.toUpperCase()}</div>
                          <div style={{ fontSize: 26, fontWeight: 800, marginTop: 6 }}>{c.v}</div>
                        </div>
                      ))}
                    </div>
                    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(260px,1fr))", gap: 12, marginTop: 14 }}>
                      <div className="stat-card">
                        <div style={{ fontSize: 12, fontWeight: 800 }}><i className="fa-solid fa-fire" style={{ color: "#f59e0b", marginRight: 8 }} />SERVER PALING RAME (7 HARI)</div>
                        {stats?.mostCrowded ? (
                          <div style={{ marginTop: 10, fontSize: 13 }}>
                            <div style={{ fontWeight: 800, fontSize: 15 }}>{stats.mostCrowded.title} <span className="badge badge-purple" style={{ marginLeft: 6 }}>{stats.mostCrowded.label}</span></div>
                            <div style={{ color: "#8a99b9", marginTop: 4 }}>{stats.mostCrowded.joins}× join • Tenant: {stats.mostCrowded.tenantSlug} • Slot {stats.mostCrowded.slot}</div>
                          </div>
                        ) : (
                          <div style={{ color: "#8a99b9", fontSize: 13, marginTop: 8 }}>Belum ada join tercatat.</div>
                        )}
                      </div>
                      <div className="stat-card">
                        <div style={{ fontSize: 12, fontWeight: 800 }}><i className="fa-solid fa-hourglass-half" style={{ color: "#ec4899", marginRight: 8 }} />SEGERA KEDALUWARSA</div>
                        <div style={{ marginTop: 10, display: "flex", flexDirection: "column", gap: 8 }}>
                          {(stats?.expiringSoon || []).length === 0 && <div style={{ fontSize: 13, color: "#8a99b9" }}>Tidak ada.</div>}
                          {(stats?.expiringSoon || []).map((e) => (
                            <div key={e.slug} style={{ display: "flex", justifyContent: "space-between", fontSize: 12.5 }}>
                              <span><b>{e.label}</b> <span style={{ color: "#6b7a99" }}>({e.slug})</span></span>
                              <span className="badge badge-amber">{e.remaining}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="panel">
                  <div className="panel-head"><i className="fa-solid fa-chart-column" style={{ color: "#22d3ee" }} /><div><div className="panel-title">Grafik 7 Hari — Visit vs Join Click</div><div className="panel-sub">Ungu = visit halaman • Pink = join click.</div></div></div>
                  <div className="panel-body">
                    <div className="bar-row">
                      {(stats?.week || []).map((w) => (
                        <div key={w.day} className="bar-col">
                          <div className="bar-stack">
                            <div className="bar bar-v" style={{ height: `${Math.max(3, (w.visit / maxBar) * 86)}px` }} title={`${w.visit} visit`} />
                            <div className="bar bar-j" style={{ height: `${Math.max(3, (w.join / maxBar) * 86)}px` }} title={`${w.join} join`} />
                          </div>
                          <div className="bar-day">{w.day.slice(5)}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </>
            )}

            {tab === "tenants" && (
              <>
                <div className="panel">
                  <div className="panel-head"><i className="fa-solid fa-key" style={{ color: "#fbbf24" }} /><div><div className="panel-title">Panel ②-A — Generate Password Penyewa Baru</div><div className="panel-sub">1 password = 1 admin sendiri. Langsung aktif & dikenali server.</div></div></div>
                  <div className="panel-body">
                    <form onSubmit={handleGenerate} style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(200px,1fr))", gap: 12 }}>
                      <div>
                        <label style={{ fontSize: 12, fontWeight: 700, color: "#8a99b9" }}>NAMA / LABEL PENYEWA</label>
                        <input className="field" style={{ marginTop: 6 }} placeholder="cth: Budi - Rental Januari" value={gLabel} onChange={(e) => setGLabel(e.target.value)} />
                      </div>
                      <div>
                        <label style={{ fontSize: 12, fontWeight: 700, color: "#8a99b9" }}>MASA AKTIF</label>
                        <select className="field" style={{ marginTop: 6 }} value={gDays} onChange={(e) => setGDays(e.target.value)}>
                          <option value="1">1 Hari</option>
                          <option value="3">3 Hari</option>
                          <option value="7">7 Hari</option>
                          <option value="30">30 Hari</option>
                          <option value="90">90 Hari</option>
                          <option value="custom">Custom (jam)</option>
                        </select>
                      </div>
                      {gDays === "custom" && (
                        <div>
                          <label style={{ fontSize: 12, fontWeight: 700, color: "#8a99b9" }}>JUMLAH JAM</label>
                          <input className="field" style={{ marginTop: 6 }} type="number" min={1} placeholder="cth: 48" value={gCustomHours} onChange={(e) => setGCustomHours(e.target.value)} />
                        </div>
                      )}
                      <div>
                        <label style={{ fontSize: 12, fontWeight: 700, color: "#8a99b9" }}>CATATAN (OPSIONAL)</label>
                        <input className="field" style={{ marginTop: 6 }} placeholder="cth: sudah bayar" value={gNote} onChange={(e) => setGNote(e.target.value)} />
                      </div>
                      <div style={{ display: "flex", alignItems: "flex-end" }}>
                        <button className="btn-primary" disabled={gLoading}>{gLoading ? "Membuat..." : "＋ Generate & Aktifkan"}</button>
                      </div>
                    </form>
                    {gResult && (
                      <div style={{ marginTop: 14, background: "rgba(16,185,129,0.08)", border: "1px solid rgba(16,185,129,0.3)", borderRadius: 14, padding: 14 }}>
                        <div style={{ fontSize: 12, fontWeight: 800, color: "#6ee7b7" }}>✅ LANGSUNG AKTIF — KIRIM INI KE PENYEWA:</div>
                        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(220px,1fr))", gap: 10, marginTop: 10 }}>
                          <div><div style={{ fontSize: 11, color: "#8a99b9", fontWeight: 700 }}>PASSWORD (TERSEMBUNYI DEFAULT)</div><div style={{ fontFamily: "monospace", fontWeight: 800, fontSize: 16, background: "#000", padding: "8px 10px", borderRadius: 8, marginTop: 4 }}>{showGResult ? gResult.password : maskPwd(gResult.password)}</div><div style={{ display: "flex", gap: 6, marginTop: 6 }}><button className="btn-ghost" onClick={() => setShowGResult((s) => !s)}>{showGResult ? "Sembunyi" : "Lihat"}</button><button className="btn-ghost" onClick={() => copy(gResult.password, "Password tersalin!")}>Salin Password</button></div></div>
                          <div><div style={{ fontSize: 11, color: "#8a99b9", fontWeight: 700 }}>KODE & LINK PUBLIK</div><div style={{ fontSize: 13, marginTop: 4 }}>Kode: <b>{gResult.slug}</b><br />Publik: <b>{gResult.publicPath}</b></div><button className="btn-ghost" style={{ marginTop: 6 }} onClick={() => copy(window.location.origin + gResult.publicPath, "Link publik tersalin!")}>Salin Link Publik</button></div>
                          <div><div style={{ fontSize: 11, color: "#8a99b9", fontWeight: 700 }}>CARA LOGIN PENYEWA</div><div style={{ fontSize: 12.5, color: "#cbd5e1", marginTop: 4 }}>Buka web → ketuk Diamond kiri-atas 3× (diam, tanpa petunjuk) → tab ADMIN → tempel password.</div></div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                <div className="panel">
                  <div className="panel-head"><i className="fa-solid fa-users" style={{ color: "#a855f7" }} /><div><div className="panel-title">Panel ②-B — Daftar Admin / Penyewa ({tenants.length})</div><div className="panel-sub">Lihat siapa login, sisa waktu, visit/join. Password hanya Owner yang bisa lihat.</div></div></div>
                  <div className="panel-body">
                    <div className="table-wrap">
                      <table className="nice">
                        <thead><tr><th>Label / Kode</th><th>Status & Sisa</th><th>Login</th><th>Visit / Join</th><th>Password (Owner)</th><th>Aksi</th></tr></thead>
                        <tbody>
                          {tenants.length === 0 && <tr><td colSpan={6} style={{ textAlign: "center", color: "#8a99b9" }}>Belum ada penyewa. Generate di atas.</td></tr>}
                          {tenants.map((t) => (
                            <tr key={t.slug}>
                              <td><b>{t.label}</b><br /><span style={{ fontFamily: "monospace", color: "#8a99b9" }}>{t.slug}</span><br /><span style={{ fontSize: 11, color: "#6b7a99" }}>{t.publicPath}</span></td>
                              <td>{t.isActive ? <span className="badge badge-green">AKTIF</span> : <span className="badge badge-red">EXPIRED/OFF</span>}<br /><span className="badge badge-amber" style={{ marginTop: 6 }}>{t.remaining}</span></td>
                              <td style={{ fontSize: 12 }}>{t.loginCount}× login<br /><span style={{ color: "#8a99b9" }}>{t.lastLoginAt ? new Date(t.lastLoginAt).toLocaleString("id-ID") : "belum pernah"}</span></td>
                              <td style={{ fontSize: 12 }}>{t.visits} visit<br />{t.joins} join</td>
                              <td><span style={{ fontFamily: "monospace", fontSize: 12, background: "#000", padding: "4px 8px", borderRadius: 6 }}>{revealed[t.slug] ? t.passwordPlain : maskPwd(t.passwordPlain)}</span><br /><div style={{ display: "flex", gap: 6, marginTop: 6 }}><button className="btn-ghost" style={{ padding: "5px 10px", fontSize: 11 }} onClick={() => toggleReveal(t.slug)}>{revealed[t.slug] ? "Sembunyi" : "Lihat"}</button><button className="btn-ghost" style={{ padding: "5px 10px", fontSize: 11 }} onClick={() => copy(t.passwordPlain, "Password tersalin!")}>Salin</button></div></td>
                              <td>
                                <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                                  <button className="btn-ghost" style={{ padding: "6px 10px", fontSize: 11 }} onClick={() => copy(window.location.origin + t.publicPath, "Link website penyewa tersalin!")}>Salin Web</button>
                                  <button className="btn-ghost" style={{ padding: "6px 10px", fontSize: 11 }} onClick={() => window.open(t.publicPath, "_blank")}>Buka Web</button>
                                  <button className="btn-green" onClick={() => act(t.slug, "extend7")}>+7H</button>
                                  <button className="btn-green" onClick={() => act(t.slug, "extend30")}>+30H</button>
                                  <button className="btn-amber" onClick={() => act(t.slug, "reset")}>Reset Link</button>
                                  <button className="btn-amber" onClick={() => act(t.slug, "regen")}>Pwd Baru</button>
                                  <button className="btn-ghost" style={{ padding: "6px 10px", fontSize: 11 }} onClick={() => act(t.slug, "toggle")}>{t.isActive ? "Off" : "On"}</button>
                                  <button className="btn-danger" onClick={() => act(t.slug, "delete")}>Hapus</button>
                                </div>
                                <div style={{ fontSize: 10.5, color: "#6b7a99", marginTop: 6 }}>Web sendiri: berisi link map milik {t.slug} saja, bukan milik orang lain.</div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </>
            )}

            {tab === "servers" && (
              <div className="panel">
                <div className="panel-head"><i className="fa-solid fa-server" style={{ color: "#22d3ee" }} /><div><div className="panel-title">Panel ③ — Setting Link Private Server (Owner) • {visibleServers.length} Server</div><div className="panel-sub">3 link per server • Total {countFilled()}/{totalLinks} • Info map otomatis dari Roblox</div></div></div>
                <div className="panel-body">
                  <div style={{ background: "rgba(16,185,129,0.08)", border: "1px solid rgba(16,185,129,0.35)", borderRadius: 12, padding: 12, fontSize: 12.5, color: "#cbd5e1", marginBottom: 14 }}>
                    <b>Server join ada 2</b> — cukup isi <b>3 link per server</b> (total <b>{totalLinks} link</b>). <b>Link 1 = DISPLAY</b> (address bar) • <b>Link 2 = LOGIN</b> (saat sign in) • <b>Link 3 = CORE</b> (private utama, ditutupi 1 & 2). Tersimpan permanen.<br />
                    🌐 <b>Website Owner:</b> <span style={{ fontFamily: "monospace" }}>{typeof window !== "undefined" ? window.location.origin + "/" : "/"}</span>
                    <button className="btn-ghost" style={{ marginLeft: 8, padding: "4px 10px", fontSize: 11 }} onClick={() => copy(typeof window !== "undefined" ? window.location.origin + "/" : "/", "Link website Owner tersalin!")}>Salin</button>
                    <button className="btn-ghost" style={{ marginLeft: 6, padding: "4px 10px", fontSize: 11 }} onClick={() => window.open("/", "_blank")}>Buka</button>
                  </div>
                  <MyWebsiteCard kind="owner" servers={servers} onCopy={copy} />
                  <WebsiteBrandingCard kind="owner" getToken={getOwnerToken} />
                  {srvErr && (
                    <div style={{ background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.3)", color: "#fca5a5", fontSize: 12.5, padding: "10px 12px", borderRadius: 12, marginBottom: 12 }}>{srvErr}</div>
                  )}
                  {srvWarn.length > 0 && (
                    <div style={{ background: "rgba(245,158,11,0.08)", border: "1px solid rgba(245,158,11,0.35)", borderRadius: 12, padding: 12, fontSize: 12.5, color: "#fcd34d", marginBottom: 14 }}>
                      {srvWarn.map((w, i) => <div key={i}>⚠️ {w}</div>)}
                    </div>
                  )}
                  {visibleServers.map((s) => {
                    const c = [(s.decoy1 || "").trim(), (s.decoy2 || "").trim(), (s.realUrl || "").trim()].filter(Boolean).length;
                    const dirty = !!dirtySlots[s.slot];
                    const saving = savingSlot === s.slot;
                    return (
                    <div key={s.slot} className="panel" style={{ marginBottom: 12, borderColor: dirty ? "rgba(245,158,11,0.4)" : undefined }}>
                      <div className="panel-head">
                        <span className="badge badge-purple">SERVER 0{s.slot}</span>
                        <input className="field" style={{ maxWidth: 200 }} value={s.title} onChange={(e) => { markDirty(s.slot); setServers((prev) => prev.map((p) => (p.slot === s.slot ? { ...p, title: e.target.value } : p))); }} />
                        <span className={`badge ${c === 3 ? "badge-green" : "badge-amber"}`} style={{ marginLeft: 8 }}>{c}/3 link</span>
                        {dirty && <span className="badge badge-amber" style={{ marginLeft: 6 }}>• Belum tersimpan</span>}
                        {!dirty && savedAt[s.slot] && <span style={{ fontSize: 11, color: "#6ee7b7", marginLeft: 8 }}>✓ {savedAt[s.slot]}</span>}
                        <label style={{ marginLeft: "auto", fontSize: 12, display: "flex", gap: 6, alignItems: "center" }}><input type="checkbox" checked={s.isActive} onChange={(e) => { markDirty(s.slot); setServers((prev) => prev.map((p) => (p.slot === s.slot ? { ...p, isActive: e.target.checked } : p))); }} /> Aktif</label>
                      </div>
                      <div className="panel-body" style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                        <div><label style={{ fontSize: 11, fontWeight: 800, color: "#93c5fd" }}>LINK 1 — DISPLAY (tampil di address bar) — map apa pun</label><input className="field" style={{ marginTop: 6, fontFamily: "monospace", fontSize: 12 }} placeholder="Tempel Link 1 map apa pun di sini..." value={s.decoy1} onChange={(e) => { markDirty(s.slot); setServers((prev) => prev.map((p) => (p.slot === s.slot ? { ...p, decoy1: e.target.value } : p))); }} /></div>
                        <div><label style={{ fontSize: 11, fontWeight: 800, color: "#fcd34d" }}>LINK 2 — LOGIN (tampil otomatis saat sign in)</label><input className="field" style={{ marginTop: 6, fontFamily: "monospace", fontSize: 12 }} placeholder="Tempel Link 2 login di sini — auto-switch ikut link ini..." value={s.decoy2} onChange={(e) => { markDirty(s.slot); setServers((prev) => prev.map((p) => (p.slot === s.slot ? { ...p, decoy2: e.target.value } : p))); }} /></div>
                        <div><label style={{ fontSize: 11, fontWeight: 800, color: "#6ee7b7" }}>LINK 3 — CORE (private utama, ditutupi 1 & 2)</label><input className="field" style={{ marginTop: 6, fontFamily: "monospace", fontSize: 12 }} placeholder="Tempel Link 3 di sini..." value={s.realUrl} onChange={(e) => { markDirty(s.slot); setServers((prev) => prev.map((p) => (p.slot === s.slot ? { ...p, realUrl: e.target.value } : p))); }} /></div>
                        {s.imageUrl ? (
                          <div style={{ display: "flex", gap: 10, alignItems: "center", background: "rgba(255,255,255,0.03)", borderRadius: 10, padding: 8 }}>
                            {/* eslint-disable-next-line @next/next/no-img-element */}
                            <img src={s.imageUrl} alt="banner" style={{ width: 120, height: 68, objectFit: "cover", borderRadius: 8 }} />
                            <div style={{ fontSize: 11.5, color: "#8a99b9" }}>Banner map saat ini (otomatis dari Roblox / bisa diganti manual di bawah).<br />Judul: <b style={{ color: "#e2e8f0" }}>{s.title}</b></div>
                          </div>
                        ) : null}
                        <div><label style={{ fontSize: 11, fontWeight: 800, color: "#8a99b9" }}>BANNER MAP (otomatis / manual)</label><input className="field" style={{ marginTop: 6, fontSize: 12 }} placeholder="https://... (kosong = pakai default)" value={s.imageUrl} onChange={(e) => { markDirty(s.slot); setServers((prev) => prev.map((p) => (p.slot === s.slot ? { ...p, imageUrl: e.target.value } : p))); }} /></div>
                        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                          <button className="btn-ghost" style={{ flex: 1 }} disabled={fetchingMap === s.slot} onClick={() => autoFillMap(s.slot)}>{fetchingMap === s.slot ? "Mengambil..." : "🔄 Ambil Map Otomatis dari Link 1"}</button>
                          <button className="btn-primary" style={{ flex: 1 }} disabled={saving} onClick={() => saveOneServer(s.slot)}>{saving ? "Menyimpan..." : `💾 Simpan Server 0${s.slot} Saja`}</button>
                        </div>
                        <div style={{ fontSize: 11, color: "#6b7a99" }}>Ganti map/link kapan pun → web + auto-switch login ikut link baru otomatis (max 15 detik).</div>
                      </div>
                    </div>
                    );
                  })}
                  {!showThird ? (
                    <button className="btn-ghost" style={{ width: "100%", marginBottom: 8 }} onClick={() => setShowThird(true)}>＋ Tampilkan Server 03 (Opsional)</button>
                  ) : (
                    <button className="btn-ghost" style={{ width: "100%", marginBottom: 8 }} onClick={() => setShowThird(false)}>－ Sembunyikan Server 03 (data tetap tersimpan)</button>
                  )}
                  <button className="btn-ghost" style={{ width: "100%" }} onClick={saveServers}>💾 Simpan Semua Sekaligus ({countFilled()}/{totalLinks})</button>
                </div>
              </div>
            )}

            {tab === "stats" && (
              <div className="panel">
                <div className="panel-head"><i className="fa-solid fa-chart-line" style={{ color: "#a855f7" }} /><div><div className="panel-title">Panel ④ — Statistik Harian Semua Tenant</div><div className="panel-sub">Per hari berapa visit + join click.</div></div></div>
                <div className="panel-body">
                  <div className="table-wrap">
                    <table className="nice">
                      <thead><tr><th>Tanggal</th><th>Visit</th><th>Join Click</th><th>Total</th></tr></thead>
                      <tbody>
                        {(stats?.week || []).map((w) => (
                          <tr key={w.day}><td><b>{w.day}</b></td><td>{w.visit}</td><td>{w.join}</td><td><b>{w.visit + w.join}</b></td></tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  <div style={{ marginTop: 14 }} className="table-wrap">
                    <table className="nice">
                      <thead><tr><th>Tenant</th><th>Visit</th><th>Join</th><th>Status</th></tr></thead>
                      <tbody>
                        {tenants.map((t) => (
                          <tr key={t.slug}><td><b>{t.label}</b> <span style={{ color: "#8a99b9" }}>({t.slug})</span></td><td>{t.visits}</td><td>{t.joins}</td><td>{t.isActive ? <span className="badge badge-green">AKTIF</span> : <span className="badge badge-red">EXPIRED</span>}</td></tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {tab === "activity" && (
              <div className="panel">
                <div className="panel-head"><i className="fa-solid fa-clock-rotate-left" style={{ color: "#22d3ee" }} /><div><div className="panel-title">Panel ⑤ — Log Aktivitas (Visit & Join)</div><div className="panel-sub">80 aktivitas terbaru semua tenant + owner.</div></div></div>
                <div className="panel-body">
                  <div className="table-wrap">
                    <table className="nice">
                      <thead><tr><th>Waktu</th><th>Tenant</th><th>Server</th><th>Tipe</th><th>IP Hash</th></tr></thead>
                      <tbody>
                        {activity.map((r) => (
                          <tr key={r.id}><td style={{ whiteSpace: "nowrap" }}>{new Date(r.createdAt).toLocaleString("id-ID")}</td><td><span style={{ fontFamily: "monospace" }}>{r.tenantSlug}</span></td><td>{r.serverSlot === 0 ? "Halaman" : `Server 0${r.serverSlot}`}</td><td>{r.type === "join" ? <span className="badge badge-purple">JOIN</span> : <span className="badge badge-green">VISIT</span>}</td><td style={{ fontFamily: "monospace", color: "#8a99b9" }}>{r.ipHash}</td></tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {tab === "download" && (
              <div className="panel">
                <div className="panel-head"><i className="fa-solid fa-download" style={{ color: "#fbbf24" }} /><div><div className="panel-title">Panel ⑥ — Download Source Code (KHUSUS OWNER)</div><div className="panel-sub">Hanya Owner. Tidak ada di web publik &amp; panel Admin. Anti-bocor.</div></div></div>
                <div className="panel-body" style={{ padding: 24 }}>
                  <div style={{ textAlign: "center" }}>
                    <div style={{ width: 64, height: 64, margin: "0 auto 14px", borderRadius: 18, background: "linear-gradient(135deg,#f59e0b,#ef4444)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 26, color: "#fff" }}><i className="fa-solid fa-file-zipper" /></div>
                    <div style={{ fontWeight: 800, fontSize: 17 }}>Full Source Code playscondogames</div>
                    <div style={{ fontSize: 13, color: "#8a99b9", marginTop: 6 }}>Next.js + PostgreSQL + multi-tenant Owner/Admin + masking Link 1/2/3.</div>
                  </div>

                  <div style={{ margin: "16px auto 0", maxWidth: 560, background: "rgba(16,185,129,0.07)", border: "1px solid rgba(16,185,129,0.3)", borderRadius: 12, padding: "12px 14px", textAlign: "left" }}>
                    <div style={{ fontWeight: 800, fontSize: 13, color: "#6ee7b7" }}>📁 Isi ZIP = FOLDER berisi BANYAK FILE TERPISAH (bukan 1 file)</div>
                    <div style={{ fontFamily: "monospace", fontSize: 12, color: "#cbd5e1", marginTop: 8, lineHeight: 1.7 }}>
                      playscondogames.zip<br />
                      └── playscondogames/<br />
                      &nbsp;&nbsp;&nbsp;&nbsp;├── src/ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(kode, terpisah per file)<br />
                      &nbsp;&nbsp;&nbsp;&nbsp;├── public/ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(gambar/video)<br />
                      &nbsp;&nbsp;&nbsp;&nbsp;├── package.json, configs, vercel.json<br />
                      &nbsp;&nbsp;&nbsp;&nbsp;├── README.md, DEPLOY.md, .env.example<br />
                      &nbsp;&nbsp;&nbsp;&nbsp;└── README-OWNER.txt, CARA-EXTRACT-DULU.txt
                    </div>
                    <div style={{ fontSize: 12, color: "#8a99b9", marginTop: 8 }}>Tidak perlu susun satu per satu — struktur folder sudah rapi. Kalau 1 file error, cukup perbaiki file itu saja.</div>
                  </div>

                  <div style={{ margin: "12px auto 0", maxWidth: 560, background: "rgba(245,158,11,0.08)", border: "1px solid rgba(245,158,11,0.35)", borderRadius: 12, padding: "12px 14px", textAlign: "left" }}>
                    <div style={{ fontWeight: 800, fontSize: 13, color: "#fcd34d" }}>⚠️ WAJIB EXTRACT DULU setelah download</div>
                    <div style={{ fontSize: 12.5, color: "#cbd5e1", marginTop: 6, lineHeight: 1.7 }}>
                      1. Klik kanan file .zip → <b>Extract All / Extract Here</b> (HP: tap → Extract)<br />
                      2. Masuk ke folder hasil: <b>playscondogames/</b><br />
                      3. Upload ke GitHub = upload <b>ISI folder</b> itu (bukan file .zip-nya)<br />
                      4. File <b>.env TIDAK ikut</b> (aman) — pakai <b>.env.example</b> sebagai contoh
                    </div>
                  </div>

                  {dlErr && (
                    <div style={{ margin: "14px auto 0", maxWidth: 560, background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.3)", color: "#fca5a5", fontSize: 12.5, padding: "10px 12px", borderRadius: 12 }}>{dlErr}</div>
                  )}
                  {dlOk && (
                    <div style={{ margin: "14px auto 0", maxWidth: 560, background: "rgba(16,185,129,0.1)", border: "1px solid rgba(16,185,129,0.3)", color: "#6ee7b7", fontSize: 12.5, padding: "10px 12px", borderRadius: 12 }}>{dlOk}</div>
                  )}
                  <div style={{ textAlign: "center" }}>
                    <button
                      className="btn-primary"
                      style={{ maxWidth: 340, margin: "18px auto 0", background: "linear-gradient(90deg,#f59e0b,#ef4444)" }}
                      disabled={dlLoading}
                      onClick={handleOwnerDownload}
                    >
                      {dlLoading ? "Menyiapkan ZIP..." : "⬇ Download Folder (.zip)"}
                    </button>
                    <div style={{ fontSize: 11.5, color: "#6b7a99", marginTop: 12 }}>Butuh sesi Owner aktif • token hanya via header, tidak via URL • dibatasi 5× per 10 menit.<br />JANGAN bagikan file ini ke penyewa/publik.</div>
                  </div>
                </div>
              </div>
            )}

            {tab === "settings" && (
              <div className="panel">
                <div className="panel-head"><i className="fa-solid fa-gear" style={{ color: "#8a99b9" }} /><div><div className="panel-title">Panel ⑦ — Pengaturan Owner</div><div className="panel-sub">Ganti password khusus Owner.</div></div></div>
                <div className="panel-body">
                  <form onSubmit={changePwd} style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(220px,1fr))", gap: 12, maxWidth: 640 }}>
                    <div><label style={{ fontSize: 12, fontWeight: 700, color: "#8a99b9" }}>PASSWORD LAMA</label><input className="field" style={{ marginTop: 6 }} type="password" placeholder="••••••••" value={oldPwd} onChange={(e) => setOldPwd(e.target.value)} autoComplete="off" spellCheck={false} /></div>
                    <div><label style={{ fontSize: 12, fontWeight: 700, color: "#8a99b9" }}>PASSWORD BARU (MIN 8)</label><input className="field" style={{ marginTop: 6 }} type="password" placeholder="••••••••" value={newPwd} onChange={(e) => setNewPwd(e.target.value)} autoComplete="off" spellCheck={false} /></div>
                    <div style={{ display: "flex", alignItems: "flex-end" }}><button className="btn-primary">Simpan Password Baru</button></div>
                  </form>
                  <div style={{ marginTop: 16, fontSize: 12.5, color: "#8a99b9" }}>Password tidak pernah ditampilkan di layar demi keamanan. Token sesi tersimpan di sessionStorage &amp; otomatis hilang saat tab ditutup.</div>
                </div>
              </div>
            )}
          </main>
        </div>

        <style>{`@media(max-width:900px){div[style*="grid-template-columns: 230px 1fr"]{grid-template-columns:1fr !important;}aside{position:static !important;}}`}</style>
      </div>
    </AntiInspect>
  );
}
