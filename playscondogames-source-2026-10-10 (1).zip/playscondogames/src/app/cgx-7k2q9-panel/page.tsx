"use client";

import { useEffect, useState } from "react";
import SecretGate from "@/components/SecretGate";
import AntiInspect from "@/components/AntiInspect";

function getToken(key: string): string {
  try {
    return sessionStorage.getItem(key) || localStorage.getItem(key) || "";
  } catch {
    return "";
  }
}

export default function LegacyPanel() {
  const [show, setShow] = useState(true);

  useEffect(() => {
    const ot = getToken("cg_owner_token");
    const at = getToken("cg_admin_token");
    if (ot) window.location.href = "/owner";
    else if (at) window.location.href = "/admin";
  }, []);

  return (
    <AntiInspect>
      <div style={{ minHeight: "100vh", background: "#0b0914", display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}>
        <div style={{ textAlign: "center", color: "#8a99b9", fontSize: 13 }}>Memuat panel aman...</div>
        {show && <SecretGate onClose={() => { setShow(false); window.location.href = "/"; }} />}
      </div>
    </AntiInspect>
  );
}
