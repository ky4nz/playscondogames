import PublicHome from "@/components/PublicHome";

export const dynamic = "force-dynamic";

export default async function TenantPublicPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  return <PublicHome initialTenant={slug} />;
}
